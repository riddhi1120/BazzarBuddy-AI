import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import Sidebar from './components/Sidebar.jsx';
import Dashboard from './components/Dashboard.jsx';
import Billing from './components/Billing.jsx';
import Inventory from './components/Inventory.jsx';
import Udhar from './components/Udhar.jsx';
import Customers from './components/Customers.jsx';
import LoginPage, { AUTH_KEY } from './components/LoginPage.jsx';
import { Suppliers, Expenses, Reports, Notifications, Settings, ExtraStyles } from './components/ExtraPages.jsx';

function ProtectedLayout(){
 const location=useLocation();
 if(!localStorage.getItem(AUTH_KEY)) return <Navigate to="/login" replace state={{from:location.pathname}}/>;
 return <><ExtraStyles/><div className="app-shell"><Sidebar/><main className="app-main"><Routes>
  <Route path="/dashboard" element={<Dashboard/>}/><Route path="/billing" element={<Billing/>}/><Route path="/inventory" element={<Inventory/>}/><Route path="/udhar" element={<Udhar/>}/><Route path="/customers" element={<Customers/>}/>
  <Route path="/analytics" element={<Navigate to="/reports" replace/>}/><Route path="/suppliers" element={<Suppliers/>}/><Route path="/expenses" element={<Expenses/>}/><Route path="/payments" element={<Navigate to="/billing" replace/>}/><Route path="/staff" element={<Navigate to="/settings" replace/>}/><Route path="/reports" element={<Reports/>}/><Route path="/notifications" element={<Notifications/>}/><Route path="/settings" element={<Settings/>}/>
  <Route path="*" element={<Navigate to="/dashboard" replace/>}/>
 </Routes></main></div></>;
}
export default function App(){return <Routes><Route path="/" element={<Navigate to="/login" replace/>}/><Route path="/login" element={<LoginPage/>}/><Route path="/*" element={<ProtectedLayout/>}/></Routes>}
