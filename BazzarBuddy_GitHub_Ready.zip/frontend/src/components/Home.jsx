import React, { useState, useMemo, useRef, useEffect } from "react";
import {
  LayoutDashboard, Receipt, Package, Wallet, BarChart3, Bell, Search,
  ChevronDown, ChevronRight, TrendingUp, TrendingDown, AlertTriangle, Sparkles,
  IndianRupee, Plus, X, LogOut, Settings, HelpCircle, MessageCircle,
  CheckCircle2, Clock, Trash2, Store, ArrowUpRight, User, Phone, Calendar,
  LogIn, Users
} from "lucide-react";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, Cell
} from "recharts";

/* ---------------------------- mock data ---------------------------- */

const NAV_ITEMS = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "billing", label: "Billing / POS", icon: Receipt },
  { id: "inventory", label: "Inventory", icon: Package },
  { id: "udhar", label: "Udhar", icon: Wallet },
  { id: "analytics", label: "Analytics", icon: BarChart3 },
];

const STAT_CARDS = [
  { key: "sales", label: "Today's sales", value: "\u20B918,240", change: "+12%", trend: "up", icon: IndianRupee },
  { key: "profit", label: "Total profit", value: "\u20B94,120", change: "+8%", trend: "up", icon: TrendingUp },
  { key: "stock", label: "Stock value", value: "\u20B92.1L", change: "-2%", trend: "down", icon: Package },
  { key: "udhar", label: "Udhar pending", value: "\u20B96,850", change: "+15%", trend: "up", icon: Wallet, warn: true },
];

const STAT_DETAILS = {
  sales: {
    title: "Today's sales",
    total: "\u20B918,240",
    note: "12% higher than yesterday \u2014 driven by evening grocery footfall.",
    rows: [
      { label: "Groceries", value: "\u20B99,200" },
      { label: "Dairy", value: "\u20B93,100" },
      { label: "Snacks", value: "\u20B92,800" },
      { label: "Personal care", value: "\u20B91,600" },
      { label: "Beverages", value: "\u20B91,540" },
    ],
    footLabel: "Total sales",
  },
  profit: {
    title: "Total profit",
    total: "\u20B94,120",
    note: "Margin holding steady at 22.6% across today's bills.",
    rows: [
      { label: "Total revenue", value: "\u20B918,240" },
      { label: "Cost of goods sold", value: "\u2212\u20B914,120" },
      { label: "Net profit", value: "\u20B94,120" },
      { label: "Profit margin", value: "22.6%" },
    ],
    footLabel: "Net profit",
  },
  stock: {
    title: "Stock value",
    total: "\u20B92.1L",
    note: "Groceries make up the largest share of current inventory.",
    rows: [
      { label: "Groceries", value: "\u20B992,000" },
      { label: "Snacks", value: "\u20B935,200" },
      { label: "Personal care", value: "\u20B931,700" },
      { label: "Dairy", value: "\u20B928,500" },
      { label: "Beverages", value: "\u20B922,600" },
    ],
    footLabel: "Total stock value",
  },
  udhar: {
    title: "Udhar pending",
    total: "\u20B96,850",
    note: "Ramesh Kumar's balance is 6 days overdue \u2014 consider a reminder.",
    rows: [
      { label: "Ramesh Kumar", value: "\u20B92,400", tag: "6 days overdue" },
      { label: "Suresh Patel", value: "\u20B91,850" },
      { label: "Meena Ben", value: "\u20B91,200" },
      { label: "Others (4 customers)", value: "\u20B91,400" },
    ],
    footLabel: "Total pending",
  },
};

const OWNER = {
  name: "Chauhan Bhumi",
  initials: "CB",
  role: "Shop owner",
  shop: "Bhumi General Store",
  phone: "+91 98765 43210",
  since: "Member since Jan 2023",
  stats: [
    { label: "Bills this month", value: "312" },
    { label: "Regular customers", value: "86" },
    { label: "Avg. daily sales", value: "\u20B916,900" },
  ],
};

const AI_SUGGESTIONS = [
  { icon: TrendingUp, tone: "cyan", text: "Sugar likely to run out in 3 days \u2014 reorder 40kg based on sales trend" },
  { icon: AlertTriangle, tone: "amber", text: "12 packets of biscuits expiring in 5 days \u2014 consider a discount" },
  { icon: Receipt, tone: "violet", text: "Ramesh Kumar has a pattern of late udhar repayment" },
  { icon: TrendingUp, tone: "cyan", text: "Tea powder sales up 22% this week \u2014 stock up before the weekend rush" },
];

const INVENTORY_INIT = [
  { id: "tea", name: "Tea powder", category: "Groceries", price: 140, stock: 48, threshold: 20, unitsSoldToday: 142 },
  { id: "rice", name: "Rice (25kg)", category: "Groceries", price: 1450, stock: 22, threshold: 10, unitsSoldToday: 98 },
  { id: "soap", name: "Soap bars", category: "Personal care", price: 35, stock: 60, threshold: 25, unitsSoldToday: 87 },
  { id: "sugar", name: "Sugar (1kg)", category: "Groceries", price: 46, stock: 4, threshold: 20, unitsSoldToday: 76 },
  { id: "oil", name: "Cooking oil (1L)", category: "Groceries", price: 165, stock: 2, threshold: 15, unitsSoldToday: 41 },
  { id: "atta", name: "Atta (5kg)", category: "Groceries", price: 260, stock: 7, threshold: 20, unitsSoldToday: 33 },
  { id: "salt", name: "Salt (1kg)", category: "Groceries", price: 22, stock: 9, threshold: 25, unitsSoldToday: 18 },
  { id: "biscuit", name: "Biscuits", category: "Snacks", price: 30, stock: 54, threshold: 20, unitsSoldToday: 29 },
];

const EXPIRY_ALERTS = [
  { name: "Milk packets", days: 2 },
  { name: "Bread", days: 4 },
  { name: "Paneer", days: 6 },
];

const NOTIFICATIONS_INIT = [
  { id: 1, text: "Sugar stock critical \u2014 only 4kg left", time: "10 min ago", unread: true, type: "warn" },
  { id: 2, text: "Milk packets expiring in 2 days", time: "32 min ago", unread: true, type: "danger" },
  { id: 3, text: "Ramesh Kumar udhar overdue by 6 days", time: "1 hr ago", unread: true, type: "info" },
  { id: 4, text: "New bill #1042 created \u2014 \u20B91,240", time: "2 hr ago", unread: false, type: "success" },
  { id: 5, text: "Rice (25kg) restocked \u2014 50 units added", time: "Yesterday", unread: false, type: "success" },
];

const SALES_7D = [
  { d: "Mon", s: 14200 }, { d: "Tue", s: 15800 }, { d: "Wed", s: 13100 },
  { d: "Thu", s: 16900 }, { d: "Fri", s: 19200 }, { d: "Sat", s: 22400 }, { d: "Sun", s: 18240 },
];
const SALES_30D = [
  { d: "Week 1", s: 98500 }, { d: "Week 2", s: 112300 }, { d: "Week 3", s: 105800 }, { d: "Week 4", s: 121600 },
];

const CATEGORY_DATA = [
  { name: "Groceries", value: 82000 },
  { name: "Snacks", value: 31200 },
  { name: "Personal care", value: 28700 },
  { name: "Dairy", value: 24500 },
  { name: "Beverages", value: 19800 },
];

const TONE = {
  cyan: { fg: "#22D3EE", bg: "rgba(34,211,238,0.12)" },
  amber: { fg: "#FBBF24", bg: "rgba(251,191,36,0.12)" },
  violet: { fg: "#C084FC", bg: "rgba(192,132,252,0.12)" },
  rose: { fg: "#FB7185", bg: "rgba(251,113,133,0.12)" },
  green: { fg: "#34D399", bg: "rgba(52,211,153,0.12)" },
};

const CAT_COLORS = ["#22D3EE", "#C084FC", "#34D399", "#FBBF24", "#FB7185"];

/* ------------------------------ helpers ------------------------------ */

function timeAgo() { return "just now"; }

/* ------------------------------ component ----------------------------- */

function LoginPage({ owner, onLogin }) {
  const [phone, setPhone] = useState(owner.phone);
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  function handleSubmit(e) {
    e.preventDefault();
    if (!phone.trim() || !password.trim()) {
      setError("Enter your phone number and password to log in.");
      return;
    }
    setError("");
    onLogin();
  }

  const FEATURES = [
    { icon: Receipt, text: "Create bills in seconds, right from your phone" },
    { icon: Package, text: "Real-time inventory with low-stock alerts" },
    { icon: Wallet, text: "Track udhar (credit) per customer, automatically" },
    { icon: Sparkles, text: "AI suggestions on reorders, pricing and trends" },
  ];

  return (
    <div className="bb-login-root">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700;800&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500;600&display=swap');
        .bb-login-root {
          --bg-void: #0A0E17;
          --bg-surface: #131a2b;
          --bg-surface-2: #1a2338;
          --bg-surface-3: #212c47;
          --border: #262f47;
          --text-hi: #EEF1F8;
          --text-lo: #8B93A7;
          --text-faint: #5C637A;
          --cyan: #22D3EE;
          --violet: #C084FC;
          --green: #34D399;
          --amber: #FBBF24;
          --rose: #FB7185;
          font-family: 'Inter', sans-serif;
          background: var(--bg-void);
          color: var(--text-hi);
          min-height: 100vh;
          width: 100%;
          display: grid;
          grid-template-columns: 1.15fr 1fr;
        }
        .bb-login-root * { box-sizing: border-box; }
        .bb-display { font-family: 'Sora', sans-serif; }
        .bb-mono { font-family: 'JetBrains Mono', monospace; }

        /* left brand panel */
        .bb-login-brand {
          position: relative; overflow: hidden;
          background:
            radial-gradient(circle at 15% 15%, rgba(34,211,238,0.16), transparent 45%),
            radial-gradient(circle at 85% 80%, rgba(192,132,252,0.16), transparent 45%),
            var(--bg-surface);
          border-right: 1px solid var(--border);
          padding: 48px 56px;
          display: flex; flex-direction: column; justify-content: space-between;
        }
        .bb-login-brand::before {
          content: ''; position: absolute; inset: 0; opacity: 0.5; pointer-events: none;
          background-image: radial-gradient(circle, var(--border) 1px, transparent 1px);
          background-size: 26px 26px;
          -webkit-mask-image: linear-gradient(180deg, black, transparent 70%);
          mask-image: linear-gradient(180deg, black, transparent 70%);
        }
        .bb-login-badge {
          display: inline-flex; align-items: center; gap: 8px; width: fit-content;
          background: var(--bg-surface-2); border: 1px solid var(--border); border-radius: 999px;
          padding: 6px 14px 6px 8px; font-size: 12px; color: var(--text-lo); font-weight: 600;
          position: relative;
        }
        .bb-login-feature {
          display: flex; align-items: flex-start; gap: 14px; padding: 12px 0; position: relative;
        }
        .bb-login-feature-icon {
          width: 34px; height: 34px; border-radius: 10px; flex-shrink: 0;
          background: var(--bg-surface-2); border: 1px solid var(--border);
          display: flex; align-items: center; justify-content: center; color: var(--cyan);
        }
        .bb-login-stats {
          display: grid; grid-template-columns: repeat(3, 1fr); gap: 14px; position: relative;
        }
        .bb-login-stat {
          background: var(--bg-surface-2); border: 1px solid var(--border); border-radius: 12px;
          padding: 14px 12px;
        }

        /* right form panel */
        .bb-login-formside {
          display: flex; align-items: center; justify-content: center; padding: 40px 24px;
        }
        .bb-login-card { width: 380px; max-width: 100%; }
        .bb-login-logo {
          width: 42px; height: 42px; border-radius: 12px; margin-bottom: 22px;
          background: linear-gradient(135deg, var(--cyan), var(--violet));
          display: flex; align-items: center; justify-content: center; color: #0A0E17;
        }
        .bb-login-input {
          background: var(--bg-surface-2); border: 1px solid var(--border); border-radius: 10px;
          padding: 12px 13px; color: var(--text-hi); font-size: 13.5px; outline: none; width: 100%;
          transition: border-color 0.15s ease, box-shadow 0.15s ease;
        }
        .bb-login-input:focus { border-color: var(--cyan); box-shadow: 0 0 0 3px rgba(34,211,238,0.12); }
        .bb-login-btn {
          background: linear-gradient(90deg, var(--cyan), var(--violet));
          color: #0A0E17; font-weight: 700; border: none; border-radius: 12px;
          padding: 13px 20px; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px;
          transition: filter 0.15s ease, transform 0.12s ease; font-size: 14.5px; width: 100%;
        }
        .bb-login-btn:hover { filter: brightness(1.08); transform: translateY(-1px); }
        .bb-login-btn:active { transform: translateY(0); }
        .bb-login-link { color: var(--cyan); cursor: pointer; font-weight: 600; }
        .bb-login-link:hover { text-decoration: underline; }

        @media (max-width: 860px) {
          .bb-login-root { grid-template-columns: 1fr; }
          .bb-login-brand { display: none; }
        }
      `}</style>

      {/* left: brand / homepage panel */}
      <div className="bb-login-brand">
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 34 }}>
            <div className="bb-login-logo" style={{ margin: 0 }}><Store size={19} /></div>
            <span className="bb-display" style={{ fontSize: 17, fontWeight: 700 }}>BazaarBuddy AI</span>
          </div>

          <div className="bb-login-badge">
            <Sparkles size={13} color="var(--violet)" /> AI-powered billing for kirana stores
          </div>

          <h1 className="bb-display" style={{ fontSize: 32, fontWeight: 800, lineHeight: 1.25, margin: "20px 0 12px 0" }}>
            Run your dukaan smarter, every single day.
          </h1>
          <p style={{ fontSize: 14, color: "var(--text-lo)", lineHeight: 1.6, maxWidth: 420, margin: "0 0 30px 0" }}>
            Billing, inventory, udhar and analytics — all in one place, built for Indian dukaandars.
          </p>

          <div>
            {FEATURES.map((f, i) => (
              <div className="bb-login-feature" key={i}>
                <div className="bb-login-feature-icon"><f.icon size={16} /></div>
                <p style={{ fontSize: 13.5, margin: "7px 0 0 0", color: "var(--text-hi)" }}>{f.text}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="bb-login-stats">
          {owner.stats.map((s) => (
            <div className="bb-login-stat" key={s.label}>
              <p className="bb-mono" style={{ margin: 0, fontSize: 16, fontWeight: 700 }}>{s.value}</p>
              <p style={{ margin: "4px 0 0 0", fontSize: 10.5, color: "var(--text-lo)", lineHeight: 1.3 }}>{s.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* right: login form */}
      <div className="bb-login-formside">
        <div className="bb-login-card">
          <div className="bb-login-logo"><Store size={19} /></div>
          <p className="bb-display" style={{ fontWeight: 700, fontSize: 22, margin: "0 0 6px 0" }}>
            Welcome back
          </p>
          <p style={{ fontSize: 13, color: "var(--text-lo)", margin: "0 0 28px 0" }}>
            Log in to {owner.shop} to pick up right where you left off.
          </p>

          <form onSubmit={handleSubmit}>
            <label style={{ fontSize: 12, color: "var(--text-lo)", display: "block", marginBottom: 6 }}>Phone number</label>
            <input
              className="bb-login-input"
              style={{ marginBottom: 16 }}
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="+91 98765 43210"
            />

            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 6 }}>
              <label style={{ fontSize: 12, color: "var(--text-lo)" }}>Password</label>
              <span style={{ fontSize: 11.5 }} className="bb-login-link">Forgot?</span>
            </div>
            <input
              className="bb-login-input"
              style={{ marginBottom: error ? 10 : 22 }}
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter your password"
            />

            {error && <p style={{ fontSize: 12, color: "var(--rose)", margin: "0 0 14px 0" }}>{error}</p>}

            <button className="bb-login-btn" type="submit">
              <LogIn size={16} /> Log in
            </button>
          </form>

          <p style={{ fontSize: 12.5, color: "var(--text-faint)", textAlign: "center", margin: "22px 0 0 0" }}>
            New to BazaarBuddy? <span className="bb-login-link">Get started</span>
          </p>
        </div>
      </div>
    </div>
  );
}

export default function BazaarBuddyDashboard() {
  const [activeNav, setActiveNav] = useState("dashboard");
  const [notifOpen, setNotifOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [notifications, setNotifications] = useState(NOTIFICATIONS_INIT);
  const [search, setSearch] = useState("");
  const [period, setPeriod] = useState("7D");
  const [billOpen, setBillOpen] = useState(false);
  const [billItems, setBillItems] = useState([{ name: "", qty: 1, price: 0 }]);
  const [toast, setToast] = useState(null);
  const [expanded, setExpanded] = useState(false);
  const [statDetail, setStatDetail] = useState(null);
  const [profileDetailOpen, setProfileDetailOpen] = useState(false);
  const [loggedOut, setLoggedOut] = useState(true);
  const [inventory, setInventory] = useState(INVENTORY_INIT);
  const [billInvSearch, setBillInvSearch] = useState("");
  const [sellerDetail, setSellerDetail] = useState(null);
  const [stockAddItem, setStockAddItem] = useState(null);
  const [stockAddQty, setStockAddQty] = useState(10);

  const notifRef = useRef(null);
  const profileRef = useRef(null);

  useEffect(() => {
    function onClick(e) {
      if (notifRef.current && !notifRef.current.contains(e.target)) setNotifOpen(false);
      if (profileRef.current && !profileRef.current.contains(e.target)) setProfileOpen(false);
    }
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 2600);
    return () => clearTimeout(t);
  }, [toast]);

  const unreadCount = notifications.filter((n) => n.unread).length;

  function markAllRead() {
    setNotifications((ns) => ns.map((n) => ({ ...n, unread: false })));
  }
  function markOneRead(id) {
    setNotifications((ns) => ns.map((n) => (n.id === id ? { ...n, unread: false } : n)));
  }

  function handleNavClick(id) {
    setActiveNav(id);
    if (id !== "dashboard") {
      const label = NAV_ITEMS.find((n) => n.id === id)?.label;
      setToast(`${label}: everything already lives right here on your dashboard.`);
    }
  }

  const bestSellers = useMemo(
    () => [...inventory].sort((a, b) => b.unitsSoldToday - a.unitsSoldToday).slice(0, 4),
    [inventory]
  );
  const lowStock = useMemo(
    () => inventory.filter((p) => p.stock <= p.threshold).sort((a, b) => a.stock - b.stock),
    [inventory]
  );
  const filteredBestSellers = useMemo(
    () => bestSellers.filter((p) => p.name.toLowerCase().includes(search.toLowerCase())),
    [bestSellers, search]
  );
  const filteredLowStock = useMemo(
    () => lowStock.filter((p) => p.name.toLowerCase().includes(search.toLowerCase())),
    [lowStock, search]
  );
  const filteredInventory = useMemo(
    () => inventory.filter((p) => p.name.toLowerCase().includes(billInvSearch.toLowerCase())),
    [inventory, billInvSearch]
  );

  const salesData = period === "7D" ? SALES_7D : SALES_30D;

  function updateBillItem(idx, field, val) {
    setBillItems((items) => items.map((it, i) => (i === idx ? { ...it, [field]: val } : it)));
  }
  function addBillRow() {
    setBillItems((items) => [...items, { name: "", qty: 1, price: 0 }]);
  }
  function removeBillRow(idx) {
    setBillItems((items) => items.filter((_, i) => i !== idx));
  }
  const billTotal = billItems.reduce((sum, it) => sum + (Number(it.qty) || 0) * (Number(it.price) || 0), 0);

  function addInventoryToBill(item) {
    setBillItems((items) => {
      const idx = items.findIndex((it) => it.name === item.name);
      if (idx !== -1) {
        return items.map((it, i) => (i === idx ? { ...it, qty: (Number(it.qty) || 0) + 1 } : it));
      }
      const emptyIdx = items.findIndex((it) => !it.name.trim());
      if (emptyIdx !== -1) {
        return items.map((it, i) => (i === emptyIdx ? { name: item.name, qty: 1, price: item.price } : it));
      }
      return [...items, { name: item.name, qty: 1, price: item.price }];
    });
    setToast(`${item.name} added to bill`);
  }

  function submitStockAdd() {
    const qty = Number(stockAddQty);
    if (!stockAddItem || !qty || qty <= 0) {
      setToast("Enter a valid quantity.");
      return;
    }
    setInventory((inv) => inv.map((p) => (p.id === stockAddItem.id ? { ...p, stock: p.stock + qty } : p)));
    setToast(`${qty} units added to ${stockAddItem.name}`);
    setStockAddItem(null);
    setStockAddQty(10);
  }

  function submitBill() {
    const valid = billItems.filter((it) => it.name.trim() && Number(it.qty) > 0);
    if (valid.length === 0) {
      setToast("Add at least one item before creating the bill.");
      return;
    }
    setNotifications((ns) => [
      { id: Date.now(), text: `New bill created \u2014 \u20B9${billTotal.toLocaleString("en-IN")}`, time: timeAgo(), unread: true, type: "success" },
      ...ns,
    ]);
    setToast(`Bill created successfully \u2014 \u20B9${billTotal.toLocaleString("en-IN")}`);
    setBillItems([{ name: "", qty: 1, price: 0 }]);
    setBillOpen(false);
  }

  if (loggedOut) {
    return <LoginPage owner={OWNER} onLogin={() => setLoggedOut(false)} />;
  }

  return (
    <div className="bb-root">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700;800&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500;600&display=swap');

        .bb-root {
          --bg-void: #0A0E17;
          --bg-surface: #131a2b;
          --bg-surface-2: #1a2338;
          --bg-surface-3: #212c47;
          --border: #262f47;
          --text-hi: #EEF1F8;
          --text-lo: #8B93A7;
          --text-faint: #5C637A;
          --cyan: #22D3EE;
          --violet: #C084FC;
          --green: #34D399;
          --amber: #FBBF24;
          --rose: #FB7185;
          font-family: 'Inter', sans-serif;
          background: var(--bg-void);
          color: var(--text-hi);
          min-height: 100vh;
          display: flex;
          position: relative;
          overflow-x: hidden;
        }
        .bb-root * { box-sizing: border-box; }
        .bb-display { font-family: 'Sora', sans-serif; }
        .bb-mono { font-family: 'JetBrains Mono', monospace; }

        .bb-scrollbar::-webkit-scrollbar { width: 8px; height: 8px; }
        .bb-scrollbar::-webkit-scrollbar-thumb { background: var(--bg-surface-3); border-radius: 8px; }
        .bb-scrollbar::-webkit-scrollbar-track { background: transparent; }

        /* sidebar */
        .bb-sidebar {
          width: 232px;
          flex-shrink: 0;
          background: var(--bg-surface);
          border-right: 1px solid var(--border);
          display: flex;
          flex-direction: column;
          padding: 22px 14px;
          position: sticky;
          top: 0;
          height: 100vh;
        }
        .bb-logo { display: flex; align-items: center; gap: 10px; padding: 4px 8px 24px 8px; }
        .bb-logo-icon {
          width: 36px; height: 36px; border-radius: 10px;
          background: linear-gradient(135deg, var(--cyan), var(--violet));
          display: flex; align-items: center; justify-content: center;
          color: #0A0E17;
        }
        .bb-navitem {
          display: flex; align-items: center; gap: 12px;
          padding: 11px 14px; border-radius: 10px; margin-bottom: 3px;
          color: var(--text-lo); cursor: pointer; position: relative;
          font-size: 14px; font-weight: 500;
          border: 1px solid transparent;
          transition: background 0.18s ease, color 0.18s ease, transform 0.12s ease, border-color 0.18s ease;
        }
        .bb-navitem:hover { background: var(--bg-surface-2); color: var(--text-hi); transform: translateX(2px); }
        .bb-navitem.active {
          background: linear-gradient(90deg, rgba(34,211,238,0.14), rgba(192,132,252,0.08));
          color: var(--text-hi);
          border-color: rgba(34,211,238,0.25);
        }
        .bb-navitem.active::before {
          content: ''; position: absolute; left: -14px; top: 8px; bottom: 8px; width: 3px;
          border-radius: 4px; background: linear-gradient(180deg, var(--cyan), var(--violet));
        }

        /* header */
        .bb-header {
          position: sticky; top: 0; z-index: 20;
          display: flex; align-items: center; justify-content: space-between;
          padding: 18px 30px; background: rgba(10,14,23,0.85); backdrop-filter: blur(10px);
          border-bottom: 1px solid var(--border);
        }
        .bb-search {
          display: flex; align-items: center; gap: 8px;
          background: var(--bg-surface); border: 1px solid var(--border);
          border-radius: 10px; padding: 8px 14px; width: 260px;
          transition: border-color 0.18s ease, box-shadow 0.18s ease;
        }
        .bb-search:focus-within { border-color: var(--cyan); box-shadow: 0 0 0 3px rgba(34,211,238,0.12); }
        .bb-search input { background: transparent; border: none; outline: none; color: var(--text-hi); font-size: 13.5px; width: 100%; }
        .bb-search input::placeholder { color: var(--text-faint); }

        .bb-iconbtn {
          width: 40px; height: 40px; border-radius: 10px;
          display: flex; align-items: center; justify-content: center;
          background: var(--bg-surface); border: 1px solid var(--border);
          color: var(--text-lo); cursor: pointer; position: relative;
          transition: background 0.18s ease, color 0.18s ease, border-color 0.18s ease, transform 0.12s ease;
        }
        .bb-iconbtn:hover { background: var(--bg-surface-2); color: var(--cyan); border-color: rgba(34,211,238,0.3); transform: translateY(-1px); }
        .bb-badge {
          position: absolute; top: -4px; right: -4px; min-width: 17px; height: 17px; padding: 0 4px;
          border-radius: 999px; background: var(--rose); color: white; font-size: 10px; font-weight: 700;
          display: flex; align-items: center; justify-content: center; border: 2px solid var(--bg-void);
        }

        .bb-avatar {
          width: 38px; height: 38px; border-radius: 10px;
          background: linear-gradient(135deg, var(--violet), var(--cyan));
          display: flex; align-items: center; justify-content: center;
          font-weight: 700; font-size: 13px; color: #0A0E17; cursor: pointer;
          transition: transform 0.15s ease;
        }
        .bb-avatar:hover { transform: scale(1.05); }

        .bb-dropdown {
          position: absolute; top: calc(100% + 10px); right: 0;
          background: var(--bg-surface-2); border: 1px solid var(--border);
          border-radius: 14px; box-shadow: 0 20px 40px rgba(0,0,0,0.45);
          overflow: hidden; z-index: 30;
          animation: bbFadeIn 0.16s ease;
        }
        @keyframes bbFadeIn { from { opacity: 0; transform: translateY(-6px); } to { opacity: 1; transform: translateY(0); } }

        .bb-notif-item { display: flex; gap: 10px; padding: 12px 16px; cursor: pointer; transition: background 0.15s ease; border-bottom: 1px solid var(--border); }
        .bb-notif-item:last-child { border-bottom: none; }
        .bb-notif-item:hover { background: var(--bg-surface-3); }
        .bb-dot { width: 7px; height: 7px; border-radius: 50%; background: var(--cyan); flex-shrink: 0; margin-top: 6px; }

        /* main */
        .bb-main { flex: 1; min-width: 0; }
        .bb-content { padding: 26px 30px 0 30px; max-width: 1400px; }

        /* stat / ticket cards with perforated tear edge */
        .bb-stat {
          background: var(--bg-surface);
          border: 1px solid var(--border);
          border-radius: 16px 16px 0 0;
          padding: 20px 20px 22px 20px;
          position: relative;
          transition: transform 0.18s ease, border-color 0.18s ease, box-shadow 0.18s ease;
        }
        .bb-stat { cursor: pointer; }
        .bb-stat:hover { transform: translateY(-3px); border-color: rgba(34,211,238,0.35); box-shadow: 0 12px 28px rgba(0,0,0,0.35); }
        .bb-stat:focus-visible { outline: 2px solid var(--cyan); outline-offset: 2px; }
        .bb-stat-more {
          display: flex; align-items: center; gap: 2px; font-size: 10.5px; font-weight: 600;
          color: var(--text-faint); opacity: 0; transform: translateX(-4px);
          transition: opacity 0.18s ease, transform 0.18s ease, color 0.18s ease;
        }
        .bb-stat:hover .bb-stat-more { opacity: 1; transform: translateX(0); color: var(--cyan); }
        .bb-stat::after {
          content: '';
          position: absolute; left: 0; right: 0; bottom: -1px; height: 11px;
          background-image: radial-gradient(circle at 7px 0, transparent 6px, var(--bg-void) 6.5px);
          background-size: 14px 11px; background-repeat: repeat-x;
        }
        .bb-stat-icon { width: 34px; height: 34px; border-radius: 9px; display: flex; align-items: center; justify-content: center; margin-bottom: 14px; }

        .bb-card {
          background: var(--bg-surface); border: 1px solid var(--border); border-radius: 16px;
          padding: 20px 22px;
        }
        .bb-card-hover { transition: border-color 0.18s ease, transform 0.18s ease; }
        .bb-card-hover:hover { border-color: rgba(34,211,238,0.28); }

        .bb-suggestion { display: flex; gap: 12px; align-items: flex-start; padding: 11px 10px; border-radius: 10px; cursor: default; transition: background 0.15s ease; }
        .bb-suggestion:hover { background: var(--bg-surface-2); }

        .bb-clickrow:hover { background: var(--bg-surface-2); }
        .bb-listrow { display: flex; align-items: center; justify-content: space-between; padding: 11px 4px; border-bottom: 1px solid var(--border); transition: background 0.15s ease; border-radius: 6px; }
        .bb-listrow:hover { background: var(--bg-surface-2); }
        .bb-listrow:last-child { border-bottom: none; }

        .bb-bar-track { width: 100%; height: 6px; border-radius: 4px; background: var(--bg-surface-3); overflow: hidden; margin-top: 6px; }
        .bb-bar-fill { height: 100%; border-radius: 4px; transition: width 0.4s ease; }

        .bb-pill { font-size: 11px; font-weight: 700; padding: 4px 10px; border-radius: 999px; }

        .bb-btn-primary {
          background: linear-gradient(90deg, var(--cyan), var(--violet));
          color: #0A0E17; font-weight: 700; border: none; border-radius: 12px;
          padding: 13px 20px; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px;
          transition: filter 0.15s ease, transform 0.12s ease;
          font-size: 14.5px;
        }
        .bb-btn-primary:hover { filter: brightness(1.08); transform: translateY(-1px); }
        .bb-btn-primary:active { transform: translateY(0); }

        .bb-btn-ghost {
          background: transparent; border: 1px solid var(--border); color: var(--text-lo);
          border-radius: 10px; padding: 9px 14px; cursor: pointer; font-size: 13px; font-weight: 600;
          transition: all 0.15s ease;
        }
        .bb-btn-ghost:hover { border-color: var(--cyan); color: var(--cyan); }

        .bb-tab { padding: 7px 14px; border-radius: 8px; font-size: 12.5px; font-weight: 600; cursor: pointer; color: var(--text-lo); transition: all 0.15s ease; }
        .bb-tab.active { background: var(--bg-surface-3); color: var(--cyan); }
        .bb-tab:hover:not(.active) { color: var(--text-hi); }

        /* perforated section divider (signature motif) */
        .bb-tear {
          height: 1px; margin: 30px 0; position: relative;
          background-image: repeating-linear-gradient(90deg, var(--border) 0 8px, transparent 8px 14px);
        }

        /* modal */
        .bb-modal-backdrop {
          position: fixed; inset: 0; background: rgba(6,8,14,0.72); backdrop-filter: blur(3px);
          display: flex; align-items: center; justify-content: center; z-index: 50;
          animation: bbFadeIn 0.15s ease;
        }
        .bb-modal {
          background: var(--bg-surface); border: 1px solid var(--border); border-radius: 18px;
          width: 460px; max-width: 92vw; max-height: 86vh; overflow-y: auto;
          padding: 24px; box-shadow: 0 30px 60px rgba(0,0,0,0.5);
        }
        .bb-input {
          background: var(--bg-surface-2); border: 1px solid var(--border); border-radius: 8px;
          padding: 9px 10px; color: var(--text-hi); font-size: 13px; outline: none; width: 100%;
          transition: border-color 0.15s ease;
        }
        .bb-input:focus { border-color: var(--cyan); }

        /* toast */
        .bb-toast {
          position: fixed; bottom: 24px; right: 24px; z-index: 60;
          background: var(--bg-surface-2); border: 1px solid rgba(52,211,153,0.4);
          border-radius: 12px; padding: 13px 18px; display: flex; align-items: center; gap: 10px;
          box-shadow: 0 16px 32px rgba(0,0,0,0.4); animation: bbToastIn 0.25s ease; font-size: 13.5px; max-width: 340px;
        }
        @keyframes bbToastIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }

        /* footer */
        .bb-footer {
          margin-top: 40px; border-top: 1px solid var(--border);
          padding: 22px 30px 26px 30px;
          display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 14px;
        }
        .bb-footer-link { color: var(--text-lo); font-size: 12.5px; cursor: pointer; transition: color 0.15s ease; display: flex; align-items: center; gap: 6px; }
        .bb-footer-link:hover { color: var(--cyan); }

        @media (max-width: 900px) {
          .bb-sidebar { display: none; }
          .bb-search { width: 160px; }
        }
      `}</style>

      {/* ---------------- sidebar ---------------- */}
      <aside className="bb-sidebar">
        <div className="bb-logo">
          <div className="bb-logo-icon"><Store size={19} /></div>
          <span className="bb-display" style={{ fontSize: 16, fontWeight: 700 }}>BazaarBuddy AI</span>
        </div>
        <nav>
          {NAV_ITEMS.map((item) => (
            <div
              key={item.id}
              className={`bb-navitem ${activeNav === item.id ? "active" : ""}`}
              onClick={() => handleNavClick(item.id)}
            >
              <item.icon size={17} />
              {item.label}
            </div>
          ))}
        </nav>
        <div style={{ marginTop: "auto", padding: "14px 10px", borderTop: "1px solid var(--border)" }}>
          <p style={{ fontSize: 11, color: "var(--text-faint)", lineHeight: 1.5 }}>
            Every kirana, one ledger.<br />Built for Indian dukaandars.
          </p>
        </div>
      </aside>

      {/* ---------------- main ---------------- */}
      <main className="bb-main bb-scrollbar">
        {/* header */}
        <header className="bb-header">
          <div>
            <h1 className="bb-display" style={{ fontSize: 22, fontWeight: 700, margin: 0 }}>Dashboard</h1>
            <p style={{ fontSize: 13, color: "var(--text-lo)", margin: "3px 0 0 0" }}>Welcome back, here's what's happening today</p>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            <div className="bb-search">
              <Search size={15} color="var(--text-faint)" />
              <input
                placeholder="Search products…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>

            <div ref={notifRef} style={{ position: "relative" }}>
              <button className="bb-iconbtn" onClick={() => { setNotifOpen((o) => !o); setProfileOpen(false); }}>
                <Bell size={17} />
                {unreadCount > 0 && <span className="bb-badge">{unreadCount}</span>}
              </button>
              {notifOpen && (
                <div className="bb-dropdown" style={{ width: 340 }}>
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "13px 16px", borderBottom: "1px solid var(--border)" }}>
                    <span style={{ fontWeight: 700, fontSize: 14 }}>Notifications</span>
                    <span onClick={markAllRead} style={{ fontSize: 11.5, color: "var(--cyan)", cursor: "pointer", fontWeight: 600 }}>Mark all read</span>
                  </div>
                  <div style={{ maxHeight: 340, overflowY: "auto" }} className="bb-scrollbar">
                    {notifications.map((n) => (
                      <div key={n.id} className="bb-notif-item" onClick={() => markOneRead(n.id)}>
                        {n.unread ? <div className="bb-dot" style={{ background: TONE[n.type === "danger" ? "rose" : n.type === "warn" ? "amber" : n.type === "success" ? "green" : "cyan"].fg }} /> : <div style={{ width: 7 }} />}
                        <div>
                          <p style={{ fontSize: 12.5, margin: 0, color: n.unread ? "var(--text-hi)" : "var(--text-lo)", lineHeight: 1.4 }}>{n.text}</p>
                          <span style={{ fontSize: 10.5, color: "var(--text-faint)" }}>{n.time}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div ref={profileRef} style={{ position: "relative" }}>
              <div className="bb-avatar" onClick={() => { setProfileOpen((o) => !o); setNotifOpen(false); }}>{OWNER.initials}</div>
              {profileOpen && (
                <div className="bb-dropdown" style={{ width: 220 }}>
                  <div
                    style={{ padding: "14px 16px", borderBottom: "1px solid var(--border)", cursor: "pointer" }}
                    onClick={() => { setProfileDetailOpen(true); setProfileOpen(false); }}
                  >
                    <p style={{ margin: 0, fontWeight: 700, fontSize: 13.5 }}>{OWNER.name}</p>
                    <p style={{ margin: "2px 0 0 0", fontSize: 11.5, color: "var(--text-lo)" }}>{OWNER.role}</p>
                  </div>
                  {[
                    { icon: User, label: "View profile", action: () => { setProfileDetailOpen(true); setProfileOpen(false); } },
                    { icon: Settings, label: "Settings", action: () => setToast("Settings \u2014 coming soon") },
                    { icon: HelpCircle, label: "Help & support", action: () => setToast("Opening help center\u2026") },
                    { icon: LogOut, label: "Log out", action: () => { setLoggedOut(true); setProfileOpen(false); }, danger: true },
                  ].map((it) => (
                    <div key={it.label} className="bb-notif-item" style={{ padding: "11px 16px" }}
                      onClick={() => { it.action(); setProfileOpen(false); }}>
                      <it.icon size={15} color={it.danger ? "var(--rose)" : "var(--text-lo)"} />
                      <span style={{ fontSize: 13, color: it.danger ? "var(--rose)" : "var(--text-hi)" }}>{it.label}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </header>

        <div className="bb-content">
          {/* stat cards */}
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 20 }}>
            {STAT_CARDS.map((c) => {
              const tone = c.warn ? TONE.amber : c.trend === "up" ? TONE.green : TONE.rose;
              return (
                <div className="bb-stat" key={c.label} onClick={() => setStatDetail(c.key)} role="button" tabIndex={0}>
                  <div className="bb-stat-icon" style={{ background: tone.bg }}>
                    <c.icon size={17} color={tone.fg} />
                  </div>
                  <p style={{ fontSize: 12.5, color: "var(--text-lo)", margin: "0 0 6px 0" }}>{c.label}</p>
                  <p className="bb-mono" style={{ fontSize: 25, fontWeight: 600, margin: "0 0 8px 0" }}>{c.value}</p>
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
                      {c.trend === "up" ? <TrendingUp size={13} color={tone.fg} /> : <TrendingDown size={13} color={tone.fg} />}
                      <span style={{ fontSize: 12, color: tone.fg, fontWeight: 600 }}>{c.change}</span>
                      <span style={{ fontSize: 11.5, color: "var(--text-faint)" }}>vs yesterday</span>
                    </div>
                    <span className="bb-stat-more">
                      Details <ChevronRight size={11} />
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* AI suggestions + best sellers */}
          <div style={{ display: "grid", gridTemplateColumns: "1.35fr 1fr", gap: 20, marginTop: 30 }}>
            <div className="bb-card bb-card-hover">
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
                <Sparkles size={16} color="var(--violet)" />
                <span className="bb-display" style={{ fontWeight: 700, fontSize: 15 }}>AI suggestions</span>
              </div>
              {AI_SUGGESTIONS.map((s, i) => (
                <div className="bb-suggestion" key={i}>
                  <div style={{ width: 26, height: 26, borderRadius: 7, background: TONE[s.tone].bg, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, marginTop: 1 }}>
                    <s.icon size={13} color={TONE[s.tone].fg} />
                  </div>
                  <p style={{ fontSize: 13, margin: 0, lineHeight: 1.5, color: "var(--text-hi)" }}>{s.text}</p>
                </div>
              ))}
            </div>

            <div className="bb-card bb-card-hover">
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
                <span className="bb-display" style={{ fontWeight: 700, fontSize: 15 }}>Best sellers</span>
              </div>
              {filteredBestSellers.length === 0 && <p style={{ fontSize: 12.5, color: "var(--text-faint)", padding: "10px 4px" }}>No products match "{search}"</p>}
              {filteredBestSellers.map((p) => {
                const pct = Math.round((p.unitsSoldToday / filteredBestSellers[0].unitsSoldToday) * 100);
                return (
                  <div
                    key={p.id}
                    className="bb-clickrow"
                    style={{ padding: "10px 4px", cursor: "pointer", borderRadius: 8 }}
                    onClick={() => setSellerDetail(p)}
                    role="button"
                    tabIndex={0}
                  >
                    <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13 }}>
                      <span>{p.name}</span>
                      <span className="bb-mono" style={{ fontWeight: 600 }}>{p.unitsSoldToday} units</span>
                    </div>
                    <div className="bb-bar-track">
                      <div className="bb-bar-fill" style={{ width: `${pct}%`, background: "linear-gradient(90deg, var(--cyan), var(--violet))" }} />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* low stock + expiry */}
          <div style={{ display: "grid", gridTemplateColumns: "1.35fr 1fr", gap: 20, marginTop: 20 }}>
            <div className="bb-card bb-card-hover">
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 6 }}>
                <span className="bb-display" style={{ fontWeight: 700, fontSize: 15 }}>Low stock products</span>
                <span onClick={() => setExpanded((e) => !e)} style={{ fontSize: 12.5, color: "var(--cyan)", cursor: "pointer", fontWeight: 600 }}>
                  {expanded ? "Show less" : "View all"}
                </span>
              </div>
              {filteredLowStock.length === 0 && <p style={{ fontSize: 12.5, color: "var(--text-faint)", padding: "10px 4px" }}>No products match "{search}"</p>}
              {(expanded ? filteredLowStock : filteredLowStock.slice(0, 3)).map((p) => {
                const pct = Math.min(100, Math.round((p.stock / p.threshold) * 100));
                const critical = p.stock <= p.threshold / 4;
                return (
                  <div className="bb-listrow" key={p.id}>
                    <div style={{ flex: 1 }}>
                      <span style={{ fontSize: 13 }}>{p.name}</span>
                      <div className="bb-bar-track" style={{ maxWidth: 200 }}>
                        <div className="bb-bar-fill" style={{ width: `${pct}%`, background: critical ? "var(--rose)" : "var(--amber)" }} />
                      </div>
                    </div>
                    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                      <span className="bb-mono" style={{ fontSize: 13, fontWeight: 700, color: critical ? "var(--rose)" : "var(--amber)" }}>{p.stock} left</span>
                      <div
                        className="bb-iconbtn"
                        style={{ width: 30, height: 30 }}
                        onClick={() => { setStockAddItem(p); setStockAddQty(Math.max(p.threshold * 2 - p.stock, 10)); }}
                        title={`Add stock for ${p.name}`}
                      >
                        <Plus size={13} />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
              <div className="bb-card bb-card-hover">
                <span className="bb-display" style={{ fontWeight: 700, fontSize: 15 }}>Expiry alerts</span>
                <div style={{ marginTop: 10 }}>
                  {EXPIRY_ALERTS.map((e) => (
                    <div className="bb-listrow" key={e.name}>
                      <span style={{ fontSize: 13 }}>{e.name}</span>
                      <span className="bb-pill" style={{ background: e.days <= 2 ? TONE.rose.bg : TONE.amber.bg, color: e.days <= 2 ? TONE.rose.fg : TONE.amber.fg }}>
                        {e.days} days
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <button className="bb-btn-primary" onClick={() => setBillOpen(true)}>
                <Plus size={17} /> New bill
              </button>
            </div>
          </div>

          <div className="bb-tear" />

          {/* analytics */}
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <BarChart3 size={17} color="var(--cyan)" />
              <span className="bb-display" style={{ fontWeight: 700, fontSize: 17 }}>Analytics</span>
            </div>
            <div style={{ display: "flex", gap: 4, background: "var(--bg-surface)", border: "1px solid var(--border)", borderRadius: 10, padding: 4 }}>
              {["7D", "30D"].map((p) => (
                <div key={p} className={`bb-tab ${period === p ? "active" : ""}`} onClick={() => setPeriod(p)}>{p}</div>
              ))}
            </div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 20, marginBottom: 30 }}>
            <div className="bb-card bb-card-hover">
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14 }}>
                <span style={{ fontSize: 13.5, fontWeight: 600, color: "var(--text-lo)" }}>Sales trend</span>
                <span style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 12, color: "var(--green)", fontWeight: 600 }}>
                  <ArrowUpRight size={13} /> Trending up
                </span>
              </div>
              <ResponsiveContainer width="100%" height={230}>
                <LineChart data={salesData} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#232b40" vertical={false} />
                  <XAxis dataKey="d" tick={{ fill: "#8B93A7", fontSize: 11.5 }} axisLine={{ stroke: "#262f47" }} tickLine={false} />
                  <YAxis tick={{ fill: "#8B93A7", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={(v) => `${Math.round(v / 1000)}k`} />
                  <Tooltip
                    contentStyle={{ background: "#1a2338", border: "1px solid #262f47", borderRadius: 10, fontSize: 12.5 }}
                    labelStyle={{ color: "#8B93A7" }}
                    formatter={(v) => [`\u20B9${v.toLocaleString("en-IN")}`, "Sales"]}
                  />
                  <Line type="monotone" dataKey="s" stroke="#22D3EE" strokeWidth={2.5} dot={{ fill: "#22D3EE", r: 3.5 }} activeDot={{ r: 6 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>

            <div className="bb-card bb-card-hover">
              <span style={{ fontSize: 13.5, fontWeight: 600, color: "var(--text-lo)", display: "block", marginBottom: 14 }}>Stock value by category</span>
              <ResponsiveContainer width="100%" height={230}>
                <BarChart data={CATEGORY_DATA} layout="vertical" margin={{ top: 5, right: 16, left: 0, bottom: 0 }}>
                  <XAxis type="number" hide />
                  <YAxis dataKey="name" type="category" tick={{ fill: "#8B93A7", fontSize: 11.5 }} axisLine={false} tickLine={false} width={95} />
                  <Tooltip
                    contentStyle={{ background: "#1a2338", border: "1px solid #262f47", borderRadius: 10, fontSize: 12.5 }}
                    formatter={(v) => [`\u20B9${v.toLocaleString("en-IN")}`, "Value"]}
                    cursor={{ fill: "rgba(255,255,255,0.03)" }}
                  />
                  <Bar dataKey="value" radius={[0, 6, 6, 0]} barSize={16}>
                    {CATEGORY_DATA.map((_, i) => <Cell key={i} fill={CAT_COLORS[i % CAT_COLORS.length]} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* footer */}
        <footer className="bb-footer">
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div className="bb-logo-icon" style={{ width: 28, height: 28, borderRadius: 8 }}><Store size={14} /></div>
            <div>
              <p className="bb-display" style={{ margin: 0, fontSize: 12.5, fontWeight: 700 }}>BazaarBuddy AI</p>
              <p style={{ margin: 0, fontSize: 11, color: "var(--text-faint)" }}>&copy; 2026 &middot; v1.4.0 &middot; Made for Indian dukaandars</p>
            </div>
          </div>
          <div style={{ display: "flex", gap: 22 }}>
            <span className="bb-footer-link" onClick={() => setToast("Opening help center…")}><HelpCircle size={13} /> Help center</span>
            <span className="bb-footer-link" onClick={() => setToast("Opening WhatsApp support…")}><MessageCircle size={13} /> WhatsApp support</span>
            <span className="bb-footer-link" onClick={() => setToast("Privacy policy")}>Privacy policy</span>
          </div>
        </footer>
      </main>

      {/* new bill modal */}
      {billOpen && (
        <div className="bb-modal-backdrop" onClick={() => setBillOpen(false)}>
          <div className="bb-modal" onClick={(e) => e.stopPropagation()}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 18 }}>
              <span className="bb-display" style={{ fontWeight: 700, fontSize: 17 }}>New bill</span>
              <div className="bb-iconbtn" style={{ width: 32, height: 32 }} onClick={() => setBillOpen(false)}><X size={15} /></div>
            </div>

            {billItems.map((it, idx) => (
              <div key={idx} style={{ display: "grid", gridTemplateColumns: "1.6fr 0.6fr 0.8fr auto", gap: 8, marginBottom: 10, alignItems: "center" }}>
                <input className="bb-input" placeholder="Item name" value={it.name} onChange={(e) => updateBillItem(idx, "name", e.target.value)} />
                <input className="bb-input" type="number" min="1" placeholder="Qty" value={it.qty} onChange={(e) => updateBillItem(idx, "qty", e.target.value)} />
                <input className="bb-input" type="number" min="0" placeholder="Price" value={it.price} onChange={(e) => updateBillItem(idx, "price", e.target.value)} />
                <div className="bb-iconbtn" style={{ width: 34, height: 34 }} onClick={() => removeBillRow(idx)}><Trash2 size={14} color="var(--rose)" /></div>
              </div>
            ))}

            <div className="bb-btn-ghost" style={{ display: "inline-flex", alignItems: "center", gap: 6, marginBottom: 18 }} onClick={addBillRow}>
              <Plus size={13} /> Add item
            </div>

            {/* inventory picker */}
            <div style={{ borderTop: "1px dashed var(--border)", paddingTop: 16, marginBottom: 16 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
                <Package size={14} color="var(--cyan)" />
                <span className="bb-display" style={{ fontWeight: 700, fontSize: 13.5 }}>Add from inventory</span>
              </div>
              <div className="bb-search" style={{ width: "100%", marginBottom: 10 }}>
                <Search size={14} color="var(--text-faint)" />
                <input
                  placeholder="Search inventory…"
                  value={billInvSearch}
                  onChange={(e) => setBillInvSearch(e.target.value)}
                />
              </div>
              <div style={{ maxHeight: 220, overflowY: "auto" }} className="bb-scrollbar">
                {filteredInventory.length === 0 && (
                  <p style={{ fontSize: 12.5, color: "var(--text-faint)", padding: "8px 4px" }}>No products match "{billInvSearch}"</p>
                )}
                {filteredInventory.map((item) => {
                  const low = item.stock <= item.threshold;
                  return (
                    <div className="bb-listrow" key={item.id}>
                      <div>
                        <span style={{ fontSize: 13 }}>{item.name}</span>
                        <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 2 }}>
                          <span className="bb-mono" style={{ fontSize: 11.5, color: "var(--text-lo)" }}>&#8377;{item.price}</span>
                          <span style={{ fontSize: 11, color: low ? "var(--rose)" : "var(--text-faint)", fontWeight: low ? 700 : 400 }}>
                            {item.stock} in stock
                          </span>
                        </div>
                      </div>
                      <div
                        className="bb-iconbtn"
                        style={{ width: 32, height: 32 }}
                        onClick={() => addInventoryToBill(item)}
                      >
                        <Plus size={14} />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "14px 0", borderTop: "1px dashed var(--border)", marginBottom: 16 }}>
              <span style={{ fontSize: 13.5, color: "var(--text-lo)" }}>Total</span>
              <span className="bb-mono" style={{ fontSize: 21, fontWeight: 700 }}>&#8377;{billTotal.toLocaleString("en-IN")}</span>
            </div>

            <button className="bb-btn-primary" style={{ width: "100%" }} onClick={submitBill}>
              <CheckCircle2 size={17} /> Create bill
            </button>
          </div>
        </div>
      )}

      {/* stat detail modal */}
      {statDetail && (
        <div className="bb-modal-backdrop" onClick={() => setStatDetail(null)}>
          <div className="bb-modal" onClick={(e) => e.stopPropagation()}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 6 }}>
              <span className="bb-display" style={{ fontWeight: 700, fontSize: 17 }}>{STAT_DETAILS[statDetail].title}</span>
              <div className="bb-iconbtn" style={{ width: 32, height: 32 }} onClick={() => setStatDetail(null)}><X size={15} /></div>
            </div>
            <p className="bb-mono" style={{ fontSize: 28, fontWeight: 600, margin: "8px 0 4px 0" }}>{STAT_DETAILS[statDetail].total}</p>
            <p style={{ fontSize: 12.5, color: "var(--text-lo)", margin: "0 0 18px 0", lineHeight: 1.5 }}>{STAT_DETAILS[statDetail].note}</p>

            {STAT_DETAILS[statDetail].rows.map((r, i) => (
              <div className="bb-listrow" key={i}>
                <div>
                  <span style={{ fontSize: 13 }}>{r.label}</span>
                  {r.tag && <span className="bb-pill" style={{ background: TONE.rose.bg, color: TONE.rose.fg, marginLeft: 8 }}>{r.tag}</span>}
                </div>
                <span className="bb-mono" style={{ fontSize: 13, fontWeight: 600 }}>{r.value}</span>
              </div>
            ))}

            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "14px 0 0 0", marginTop: 8, borderTop: "1px dashed var(--border)" }}>
              <span style={{ fontSize: 13, color: "var(--text-lo)" }}>{STAT_DETAILS[statDetail].footLabel}</span>
              <span className="bb-mono" style={{ fontSize: 18, fontWeight: 700 }}>{STAT_DETAILS[statDetail].total}</span>
            </div>
          </div>
        </div>
      )}

      {/* best seller detail modal */}
      {sellerDetail && (
        <div className="bb-modal-backdrop" onClick={() => setSellerDetail(null)}>
          <div className="bb-modal" onClick={(e) => e.stopPropagation()}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 6 }}>
              <span className="bb-display" style={{ fontWeight: 700, fontSize: 17 }}>{sellerDetail.name}</span>
              <div className="bb-iconbtn" style={{ width: 32, height: 32 }} onClick={() => setSellerDetail(null)}><X size={15} /></div>
            </div>
            <p style={{ fontSize: 12.5, color: "var(--text-lo)", margin: "0 0 18px 0" }}>{sellerDetail.category}</p>

            <div className="bb-listrow">
              <span style={{ fontSize: 13 }}>Units sold today</span>
              <span className="bb-mono" style={{ fontSize: 13, fontWeight: 600 }}>{sellerDetail.unitsSoldToday}</span>
            </div>
            <div className="bb-listrow">
              <span style={{ fontSize: 13 }}>Price per unit</span>
              <span className="bb-mono" style={{ fontSize: 13, fontWeight: 600 }}>&#8377;{sellerDetail.price}</span>
            </div>
            <div className="bb-listrow">
              <span style={{ fontSize: 13 }}>Revenue today</span>
              <span className="bb-mono" style={{ fontSize: 13, fontWeight: 600 }}>&#8377;{(sellerDetail.price * sellerDetail.unitsSoldToday).toLocaleString("en-IN")}</span>
            </div>
            <div className="bb-listrow">
              <div>
                <span style={{ fontSize: 13 }}>Current stock</span>
                {sellerDetail.stock <= sellerDetail.threshold && (
                  <span className="bb-pill" style={{ background: TONE.rose.bg, color: TONE.rose.fg, marginLeft: 8 }}>Low stock</span>
                )}
              </div>
              <span className="bb-mono" style={{ fontSize: 13, fontWeight: 600 }}>{sellerDetail.stock} units</span>
            </div>

            <button
              className="bb-btn-primary"
              style={{ width: "100%", marginTop: 18 }}
              onClick={() => { addInventoryToBill(sellerDetail); setSellerDetail(null); setBillOpen(true); }}
            >
              <Plus size={16} /> Add to new bill
            </button>
          </div>
        </div>
      )}

      {/* add stock modal */}
      {stockAddItem && (
        <div className="bb-modal-backdrop" onClick={() => setStockAddItem(null)}>
          <div className="bb-modal" style={{ width: 360 }} onClick={(e) => e.stopPropagation()}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 18 }}>
              <span className="bb-display" style={{ fontWeight: 700, fontSize: 17 }}>Add stock</span>
              <div className="bb-iconbtn" style={{ width: 32, height: 32 }} onClick={() => setStockAddItem(null)}><X size={15} /></div>
            </div>
            <p style={{ fontSize: 13, margin: "0 0 4px 0" }}>{stockAddItem.name}</p>
            <p style={{ fontSize: 12, color: "var(--text-lo)", margin: "0 0 18px 0" }}>Currently {stockAddItem.stock} units in stock &middot; reorder level {stockAddItem.threshold}</p>

            <label style={{ fontSize: 12, color: "var(--text-lo)", display: "block", marginBottom: 6 }}>Quantity to add</label>
            <input
              className="bb-input"
              type="number"
              min="1"
              value={stockAddQty}
              onChange={(e) => setStockAddQty(e.target.value)}
              style={{ marginBottom: 18 }}
              autoFocus
            />

            <button className="bb-btn-primary" style={{ width: "100%" }} onClick={submitStockAdd}>
              <CheckCircle2 size={17} /> Add stock
            </button>
          </div>
        </div>
      )}

      {/* profile detail modal */}
      {profileDetailOpen && (
        <div className="bb-modal-backdrop" onClick={() => setProfileDetailOpen(false)}>
          <div className="bb-modal" onClick={(e) => e.stopPropagation()}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 18 }}>
              <span className="bb-display" style={{ fontWeight: 700, fontSize: 17 }}>Profile</span>
              <div className="bb-iconbtn" style={{ width: 32, height: 32 }} onClick={() => setProfileDetailOpen(false)}><X size={15} /></div>
            </div>

            <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 20 }}>
              <div className="bb-avatar" style={{ width: 54, height: 54, fontSize: 18, cursor: "default" }}>{OWNER.initials}</div>
              <div>
                <p className="bb-display" style={{ margin: 0, fontWeight: 700, fontSize: 16 }}>{OWNER.name}</p>
                <p style={{ margin: "2px 0 0 0", fontSize: 12.5, color: "var(--text-lo)" }}>{OWNER.role} &middot; {OWNER.shop}</p>
              </div>
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 18 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <Phone size={14} color="var(--text-faint)" />
                <span style={{ fontSize: 13 }}>{OWNER.phone}</span>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <Calendar size={14} color="var(--text-faint)" />
                <span style={{ fontSize: 13 }}>{OWNER.since}</span>
              </div>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10, marginBottom: 20 }}>
              {OWNER.stats.map((s) => (
                <div key={s.label} style={{ background: "var(--bg-surface-2)", border: "1px solid var(--border)", borderRadius: 10, padding: "12px 10px", textAlign: "center" }}>
                  <p className="bb-mono" style={{ margin: 0, fontSize: 15, fontWeight: 700 }}>{s.value}</p>
                  <p style={{ margin: "4px 0 0 0", fontSize: 10.5, color: "var(--text-lo)", lineHeight: 1.3 }}>{s.label}</p>
                </div>
              ))}
            </div>

            <button
              className="bb-btn-primary"
              style={{ width: "100%", background: "transparent", border: "1px solid rgba(251,113,133,0.4)", color: "var(--rose)" }}
              onClick={() => { setProfileDetailOpen(false); setLoggedOut(true); }}
            >
              <LogOut size={16} /> Log out
            </button>
          </div>
        </div>
      )}

      {/* toast */}
      {toast && (
        <div className="bb-toast">
          <CheckCircle2 size={16} color="var(--green)" />
          <span>{toast}</span>
        </div>
      )}
    </div>
  );
}