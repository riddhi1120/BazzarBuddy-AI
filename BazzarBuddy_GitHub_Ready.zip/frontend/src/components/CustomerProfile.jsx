import React, { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import Layout from "./Layout";
import Modal from "./Modal";
import { Phone, ArrowLeft } from "lucide-react";

// Mock data - replace with your real customers data source (API / shared state)
const customers = {
  1: {
    id: 1,
    name: "Dhruvi Chauhan",
    phone: "6351229083",
    address: "Not added",
    status: "Active",
    customerSince: "2026-03-12",
    totalPurchases: 0,
    udharBalance: 0,
    lastPurchase: "-",
    notes: "",
    udharHistory: [],
    purchaseHistory: [],
  },
  2: {
    id: 2,
    name: "Ramesh Kumar",
    phone: "+91 98765 43210",
    address: "24, Gandhi Road, Ahmedabad",
    status: "Active",
    customerSince: "2025-11-02",
    totalPurchases: 12400,
    udharBalance: 850,
    lastPurchase: "2026-08-02",
    notes: "Regular customer, prefers weekly grocery bulk orders.",
    udharHistory: [
      { id: 1, date: "2026-08-02", amount: 850, status: "Paid" },
      { id: 2, date: "2026-07-15", amount: 600, status: "Paid" },
    ],
    purchaseHistory: [
      { id: 1, date: "2026-08-02", items: "Groceries, Dairy", amount: 850 },
      { id: 2, date: "2026-07-20", items: "Grains, Oil", amount: 1200 },
      { id: 3, date: "2026-07-05", items: "Snacks", amount: 350 },
    ],
  },
  3: {
    id: 3,
    name: "Priya Sharma",
    phone: "+91 91234 56789",
    address: "12, Nehru Society, Ahmedabad",
    status: "Active",
    customerSince: "2026-01-20",
    totalPurchases: 8200,
    udharBalance: 0,
    lastPurchase: "2026-07-28",
    notes: "",
    udharHistory: [],
    purchaseHistory: [
      { id: 1, date: "2026-07-28", items: "Vegetables, Fruits", amount: 420 },
    ],
  },
  4: {
    id: 4,
    name: "Amit Patel",
    phone: "+91 99887 76655",
    address: "8, Satellite Road, Ahmedabad",
    status: "Overdue",
    customerSince: "2025-09-10",
    totalPurchases: 5600,
    udharBalance: 1200,
    lastPurchase: "2026-07-28",
    notes: "Follow up needed - udhar overdue by 5 days.",
    udharHistory: [
      { id: 1, date: "2026-07-28", amount: 1200, status: "Pending" },
    ],
    purchaseHistory: [
      { id: 1, date: "2026-07-28", items: "Groceries", amount: 1200 },
    ],
  },
  5: {
    id: 5,
    name: "Sunita Devi",
    phone: "+91 90011 22334",
    address: "3, Ellisbridge, Ahmedabad",
    status: "Active",
    customerSince: "2026-02-14",
    totalPurchases: 3150,
    udharBalance: 0,
    lastPurchase: "2026-08-05",
    notes: "",
    udharHistory: [
      { id: 1, date: "2026-08-05", amount: 400, status: "Paid" },
    ],
    purchaseHistory: [
      { id: 1, date: "2026-08-05", items: "Dairy, Bread", amount: 400 },
    ],
  },
  6: {
    id: 6,
    name: "Vikram Singh",
    phone: "+91 97766 55443",
    address: "17, CG Road, Ahmedabad",
    status: "Overdue",
    customerSince: "2025-12-01",
    totalPurchases: 9800,
    udharBalance: 2400,
    lastPurchase: "2026-07-20",
    notes: "",
    udharHistory: [
      { id: 1, date: "2026-07-20", amount: 2400, status: "Pending" },
    ],
    purchaseHistory: [
      { id: 1, date: "2026-07-20", items: "Grains, Oil, Spices", amount: 2400 },
    ],
  },
};

function StatCard({ label, value }) {
  return (
    <div className="bg-[#15151f] border border-[#2a2a3a] rounded-xl p-5">
      <p className="text-sm text-gray-400 mb-2">{label}</p>
      <p className="text-2xl font-semibold text-white">{value}</p>
    </div>
  );
}

function StatusPill({ status }) {
  const isPaidOrActive = status === "Paid" || status === "Active";
  return (
    <span
      className={`px-3 py-1 rounded-full text-xs font-medium ${
        isPaidOrActive ? "bg-emerald-500/15 text-emerald-400" : "bg-rose-500/15 text-rose-400"
      }`}
    >
      {status}
    </span>
  );
}

export default function CustomerProfile() {
  const { id } = useParams();
  const navigate = useNavigate();
  const customer = customers[id];

  const [notes, setNotes] = useState(customer?.notes || "");
  const [savedNote, setSavedNote] = useState(false);
  const [udharHistory, setUdharHistory] = useState(customer?.udharHistory || []);
  const [udharBalance, setUdharBalance] = useState(customer?.udharBalance || 0);
  const [showUdharModal, setShowUdharModal] = useState(false);
  const [udharForm, setUdharForm] = useState({ date: "", amount: "" });

  if (!customer) {
    return (
      <Layout>
        <div className="text-white p-8">
          <p>Customer not found.</p>
          <button
            onClick={() => navigate("/customers")}
            className="mt-4 text-blue-400 hover:text-blue-300"
          >
            ← Back to customers
          </button>
        </div>
      </Layout>
    );
  }

  const initials = customer.name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

  const handleSaveNote = () => {
    setSavedNote(true);
    setTimeout(() => setSavedNote(false), 2000);
  };

  const handleAddUdhar = (e) => {
    e.preventDefault();
    if (!udharForm.date || !udharForm.amount) return;
    const amount = Number(udharForm.amount);
    setUdharHistory((prev) => [
      { id: Date.now(), date: udharForm.date, amount, status: "Pending" },
      ...prev,
    ]);
    setUdharBalance((prev) => prev + amount);
    setUdharForm({ date: "", amount: "" });
    setShowUdharModal(false);
  };

  return (
    <Layout>
    <div className="text-white p-8">
      <button
        onClick={() => navigate("/customers")}
        className="flex items-center gap-2 text-sm text-gray-400 hover:text-white mb-6"
      >
        <ArrowLeft size={16} />
        Back to customers
      </button>

      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-fuchsia-500 to-blue-500 flex items-center justify-center text-xl font-semibold">
            {initials}
          </div>
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-2xl font-semibold">{customer.name}</h1>
              <StatusPill status={customer.status} />
            </div>
            <p className="text-sm text-gray-400 mt-1">{customer.phone}</p>
            <p className="text-sm text-gray-500">{customer.address}</p>
          </div>
        </div>
        <div className="flex gap-3">
          <a
            href={`tel:${customer.phone}`}
            className="flex items-center gap-2 bg-[#15151f] border border-[#2a2a3a] text-sm font-medium px-4 py-2 rounded-lg text-gray-300 hover:border-fuchsia-500"
          >
            <Phone size={16} />
            Call
          </a>
          <button
            onClick={() => setShowUdharModal(true)}
            className="bg-gradient-to-r from-fuchsia-500 to-blue-500 text-white text-sm font-medium px-4 py-2 rounded-lg hover:opacity-90"
          >
            + Add Udhar
          </button>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-5 mb-8">
        <StatCard label="Total purchases" value={`₹${customer.totalPurchases.toLocaleString("en-IN")}`} />
        <StatCard label="Udhar balance" value={`₹${udharBalance.toLocaleString("en-IN")}`} />
        <StatCard label="Last purchase" value={customer.lastPurchase} />
        <StatCard label="Customer since" value={customer.customerSince} />
      </div>

      <div className="grid grid-cols-2 gap-6 mb-6">
        <div className="bg-[#15151f] border border-[#2a2a3a] rounded-xl p-6">
          <h2 className="text-lg font-medium mb-4">Udhar history</h2>
          {udharHistory.length === 0 ? (
            <p className="text-sm text-gray-500">No udhar records.</p>
          ) : (
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-gray-400 border-b border-[#2a2a3a]">
                  <th className="py-2 font-normal">Date</th>
                  <th className="py-2 font-normal">Amount</th>
                  <th className="py-2 font-normal">Status</th>
                </tr>
              </thead>
              <tbody>
                {udharHistory.map((u) => (
                  <tr key={u.id} className="border-b border-[#20202c] last:border-0">
                    <td className="py-3 text-gray-400">{u.date}</td>
                    <td className="py-3">₹{u.amount.toLocaleString("en-IN")}</td>
                    <td className="py-3">
                      <StatusPill status={u.status} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        <div className="bg-[#15151f] border border-[#2a2a3a] rounded-xl p-6">
          <h2 className="text-lg font-medium mb-4">Purchase history</h2>
          {customer.purchaseHistory.length === 0 ? (
            <p className="text-sm text-gray-500">No purchases yet.</p>
          ) : (
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-gray-400 border-b border-[#2a2a3a]">
                  <th className="py-2 font-normal">Date</th>
                  <th className="py-2 font-normal">Items</th>
                  <th className="py-2 font-normal">Amount</th>
                </tr>
              </thead>
              <tbody>
                {customer.purchaseHistory.map((p) => (
                  <tr key={p.id} className="border-b border-[#20202c] last:border-0">
                    <td className="py-3 text-gray-400">{p.date}</td>
                    <td className="py-3 text-gray-400">{p.items}</td>
                    <td className="py-3">₹{p.amount.toLocaleString("en-IN")}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      <div className="bg-[#15151f] border border-[#2a2a3a] rounded-xl p-6">
        <h2 className="text-lg font-medium mb-4">Notes</h2>
        <textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          rows={3}
          placeholder="e.g. Regular customer, gets 5% discount"
          className="w-full bg-[#0b0b12] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-fuchsia-500"
        />
        <button
          onClick={handleSaveNote}
          className="mt-3 bg-gradient-to-r from-fuchsia-500 to-blue-500 text-white text-sm font-medium px-4 py-2 rounded-lg hover:opacity-90"
        >
          {savedNote ? "Saved ✓" : "Save note"}
        </button>
      </div>

      {showUdharModal && (
        <Modal title="Add Udhar" onClose={() => setShowUdharModal(false)}>
          <form onSubmit={handleAddUdhar} className="space-y-4">
            <div>
              <label className="block text-sm text-gray-400 mb-2">Date</label>
              <input
                type="date"
                value={udharForm.date}
                onChange={(e) => setUdharForm({ ...udharForm, date: e.target.value })}
                className="w-full bg-[#0b0b12] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-fuchsia-500"
                required
              />
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-2">Amount</label>
              <input
                type="number"
                value={udharForm.amount}
                onChange={(e) => setUdharForm({ ...udharForm, amount: e.target.value })}
                className="w-full bg-[#0b0b12] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-fuchsia-500"
                placeholder="e.g. 500"
                required
              />
            </div>
            <div className="flex gap-3 pt-2">
              <button
                type="submit"
                className="flex-1 bg-gradient-to-r from-fuchsia-500 to-blue-500 text-white text-sm font-medium px-4 py-2 rounded-lg hover:opacity-90"
              >
                Add
              </button>
              <button
                type="button"
                onClick={() => setShowUdharModal(false)}
                className="flex-1 bg-[#0b0b12] border border-[#2a2a3a] text-sm font-medium px-4 py-2 rounded-lg text-gray-300"
              >
                Cancel
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
    </Layout>
  );
}
