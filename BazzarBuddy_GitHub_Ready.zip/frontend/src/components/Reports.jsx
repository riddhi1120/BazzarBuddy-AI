import React, { useState } from 'react';
import Sidebar from './Sidebar';

const periods = ['Week', 'Month', 'Year'];

const dataByPeriod = {
  Week: {
    stats: [
      { label: 'This week sales', value: '₹1,12,400' },
      { label: 'This week profit', value: '₹26,800' },
      { label: 'Transactions', value: '284' },
      { label: 'Avg. order value', value: '₹396' },
    ],
    chart: [
      { label: 'Mon', value: 14200 },
      { label: 'Tue', value: 16800 },
      { label: 'Wed', value: 15100 },
      { label: 'Thu', value: 18900 },
      { label: 'Fri', value: 21400 },
      { label: 'Sat', value: 26800 },
      { label: 'Sun', value: 19200 },
    ],
  },
  Month: {
    stats: [
      { label: 'This month sales', value: '₹4,82,300' },
      { label: 'This month profit', value: '₹1,12,400' },
      { label: 'Transactions', value: '1,248' },
      { label: 'Avg. order value', value: '₹386' },
    ],
    chart: [
      { label: 'Mar', value: 340000 },
      { label: 'Apr', value: 398000 },
      { label: 'May', value: 421000 },
      { label: 'Jun', value: 389000 },
      { label: 'Jul', value: 456000 },
      { label: 'Aug', value: 482300 },
    ],
  },
  Year: {
    stats: [
      { label: 'This year sales', value: '₹52,40,600' },
      { label: 'This year profit', value: '₹12,80,900' },
      { label: 'Transactions', value: '14,620' },
      { label: 'Avg. order value', value: '₹358' },
    ],
    chart: [
      { label: '2021', value: 3200000 },
      { label: '2022', value: 3800000 },
      { label: '2023', value: 4300000 },
      { label: '2024', value: 4700000 },
      { label: '2025', value: 5040000 },
      { label: '2026', value: 5240600 },
    ],
  },
};

const categoryBreakdown = [
  { id: 1, category: 'Groceries', sales: '₹1,84,200', percent: 38 },
  { id: 2, category: 'Dairy products', sales: '₹96,500', percent: 20 },
  { id: 3, category: 'Personal care', sales: '₹72,300', percent: 15 },
  { id: 4, category: 'Snacks & beverages', sales: '₹68,900', percent: 14 },
  { id: 5, category: 'Others', sales: '₹60,400', percent: 13 },
];

const initialReports = [
  { id: 1, name: 'Monthly sales report', icon: '📈', updated: 'Updated today' },
  { id: 2, name: 'Inventory valuation report', icon: '📦', updated: 'Updated 2 hours ago' },
  { id: 3, name: 'Udhar outstanding report', icon: '📒', updated: 'Updated today' },
  { id: 4, name: 'Profit & loss statement', icon: '💰', updated: 'Updated yesterday' },
];

function TopBar() {
  return (
    <header className="w-full flex items-center justify-between px-6 py-4 border-b border-white/10 bg-black/30 backdrop-blur-md">
      <div>
        <h1 className="text-lg font-semibold text-white">Reports</h1>
        <p className="text-xs text-slate-400">Sales, profit and inventory insights for your store</p>
      </div>
      <div className="flex items-center gap-4">
        <button className="text-slate-300 hover:text-cyan-300 transition-colors duration-200">🔔</button>
        <div className="w-8 h-8 rounded-full bg-gradient-to-r from-cyan-500 to-fuchsia-500 flex items-center justify-center text-xs font-medium text-white">
          RS
        </div>
      </div>
    </header>
  );
}

function StatCard({ label, value }) {
  return (
    <div className="bg-white/5 border border-white/10 rounded-xl p-4 hover:border-cyan-400/40 hover:shadow-[0_0_15px_rgba(34,211,238,0.2)] transition-all duration-200">
      <p className="text-xs text-slate-400 mb-1">{label}</p>
      <p className="text-xl font-semibold text-white">{value}</p>
    </div>
  );
}

function PeriodSelector({ selected, onChange }) {
  return (
    <div className="flex gap-2 bg-white/5 border border-white/10 rounded-lg p-1">
      {periods.map((p) => (
        <button
          key={p}
          onClick={() => onChange(p)}
          className={`px-4 py-1.5 rounded-md text-xs font-medium transition-all duration-200 ${
            selected === p
              ? 'bg-gradient-to-r from-cyan-500 to-fuchsia-500 text-white shadow-[0_0_12px_rgba(217,70,239,0.35)]'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          {p}
        </button>
      ))}
    </div>
  );
}

function SalesChart({ chartData }) {
  const [hoverIndex, setHoverIndex] = useState(null);
  const maxValue = Math.max(...chartData.map((m) => m.value));

  return (
    <div className="bg-white/5 border border-white/10 rounded-xl p-4 hover:border-cyan-400/30 transition-all duration-200">
      <h3 className="text-sm font-semibold text-white mb-4">Sales trend</h3>
      <div className="flex items-end justify-between gap-3 h-44 relative">
        {chartData.map((m, i) => (
          <div
            key={m.label}
            className="flex flex-col items-center flex-1 gap-2 h-full justify-end relative"
            onMouseEnter={() => setHoverIndex(i)}
            onMouseLeave={() => setHoverIndex(null)}
          >
            {hoverIndex === i && (
              <div className="absolute -top-8 bg-[#1e1e2e] border border-cyan-400/30 text-white text-xs px-2 py-1 rounded-md whitespace-nowrap z-10">
                ₹{m.value.toLocaleString('en-IN')}
              </div>
            )}
            <div
              className={`w-full rounded-t-md transition-all duration-200 cursor-pointer ${
                hoverIndex === i
                  ? 'bg-gradient-to-t from-fuchsia-500 to-cyan-400 opacity-100'
                  : 'bg-gradient-to-t from-cyan-500 to-fuchsia-500 opacity-80'
              }`}
              style={{ height: `${(m.value / maxValue) * 100}%` }}
            ></div>
            <span className="text-xs text-slate-400">{m.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function CategoryBreakdown() {
  return (
    <div className="bg-white/5 border border-white/10 rounded-xl p-4 hover:border-fuchsia-400/30 transition-all duration-200">
      <h3 className="text-sm font-semibold text-white mb-3">Sales by category</h3>
      <ul className="flex flex-col gap-3">
        {categoryBreakdown.map((c) => (
          <li key={c.id}>
            <div className="flex justify-between text-sm mb-1">
              <span className="text-slate-300">{c.category}</span>
              <span className="text-slate-200 font-medium">{c.sales}</span>
            </div>
            <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-cyan-500 to-fuchsia-500 transition-all duration-500"
                style={{ width: `${c.percent}%` }}
              ></div>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

function downloadCSV(reportName, chartData) {
  const rows = [['Label', 'Value'], ...chartData.map((d) => [d.label, d.value])];
  const csvContent = rows.map((r) => r.join(',')).join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${reportName.replace(/\s+/g, '_').toLowerCase()}.csv`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

function ReportsList({ chartData }) {
  const [downloadedId, setDownloadedId] = useState(null);

  const handleDownload = (report) => {
    downloadCSV(report.name, chartData);
    setDownloadedId(report.id);
    setTimeout(() => setDownloadedId(null), 2000);
  };

  return (
    <div className="bg-white/5 border border-white/10 rounded-xl p-4 hover:border-cyan-400/30 transition-all duration-200">
      <h3 className="text-sm font-semibold text-white mb-3">Available reports</h3>
      <ul className="flex flex-col gap-2">
        {initialReports.map((r) => (
          <li
            key={r.id}
            className="flex items-center justify-between p-3 rounded-lg bg-white/5 hover:bg-white/10 transition-colors duration-150"
          >
            <div className="flex items-center gap-3">
              <span className="text-lg">{r.icon}</span>
              <div>
                <p className="text-sm text-slate-200 font-medium">{r.name}</p>
                <p className="text-xs text-slate-500">{r.updated}</p>
              </div>
            </div>
            <button
              onClick={() => handleDownload(r)}
              className={`text-xs font-medium px-3 py-1.5 rounded-md transition-all duration-200 ${
                downloadedId === r.id
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-400/30'
                  : 'text-cyan-300 hover:text-cyan-200 hover:bg-white/5 border border-transparent'
              }`}
            >
              {downloadedId === r.id ? '✓ Downloaded' : 'Download'}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default function Reports() {
  const [period, setPeriod] = useState('Month');
  const currentData = dataByPeriod[period];

  return (
    <div className="w-full min-h-screen bg-[#0a0a12] flex">
      <Sidebar />
      <div className="flex-1 flex flex-col">
        <TopBar />
        <main className="p-6 flex-1">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm text-slate-400">Overview</h2>
            <PeriodSelector selected={period} onChange={setPeriod} />
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
            {currentData.stats.map((s) => (
              <StatCard key={s.label} label={s.label} value={s.value} />
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-[1.3fr_1fr] gap-4 mb-4">
            <SalesChart chartData={currentData.chart} />
            <CategoryBreakdown />
          </div>

          <ReportsList chartData={currentData.chart} />
        </main>
      </div>
    </div>
  );
}