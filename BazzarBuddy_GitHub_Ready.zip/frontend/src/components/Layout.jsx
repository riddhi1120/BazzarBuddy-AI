import React from "react";
import Sidebar from "./Sidebar";
import { Bell } from "lucide-react";

export default function Layout({ children }) {
  return (
    <div className="flex min-h-screen bg-[#0b0b12]">
      <Sidebar />
      <div className="flex-1 flex flex-col">
        <div className="flex items-center justify-end gap-5 px-8 py-5 border-b border-[#2a2a3a]">
          <Bell size={20} className="text-gray-400 hover:text-white cursor-pointer" />
          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-fuchsia-500 to-blue-500 flex items-center justify-center text-sm font-medium text-white">
            CB
          </div>
        </div>
        <div className="flex-1">{children}</div>
      </div>
    </div>
  );
}
