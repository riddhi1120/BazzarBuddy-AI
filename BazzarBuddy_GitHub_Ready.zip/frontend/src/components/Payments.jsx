import React, { useState } from "react";
import Layout from "./Layout";
import Modal from "./Modal";

const initialPayments = [
  { id: 1, date: "2026-08-09", source: "Billing", mode: "Cash", amount: 1450, ref: "-" },
  { id: 2, date: "2026-08-09", source: "Billing", mode: "UPI", amount: 2300, ref: "UPI2026080901" },
  { id: 3, date: "2026-08-08", source: "Udhar", mode: "Cash", amount: 850, ref: "-" },
  { id: 4, date: "2026-08-08", source: "Billing", mode: "Card", amount: 600, ref: "CARD448821" },
];

const sources = ["All", "Billing", "Udhar", "Manual"];
const modes = ["All", "Cash", "UPI", "Bank", "Card"];
const formModes = ["Cash", "UPI", "Bank", "Card"];

function StatCard({ label, value }) {
  return (
    <div className="bg-[#15151f] border border-[#2a2a3a] rounded-xl p-5">
      <p className="text-sm text-gray-400 mb-2">{label}</p>
      <p className="text-2xl font-semibold text-white">{value}</p>
    </div>
  );
}

const emptyForm = { date: "", source: "Manual", mode: "Cash", amount: "", ref: "" };

export default function Payments() {
  const [payments, setPayments] = useState(initialPayments);
  const [sourceFilter, setSourceFilter] = useState("All");
  const [modeFilter, setModeFilter] = useState("All");
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState(emptyForm);

  const today = "2026-08-09";

  const filtered = payments.filter(
    (p) =>
      (sourceFilter === "All" || p.source === sourceFilter) &&
      (modeFilter === "All" || p.mode === modeFilter)
  );

  const cashInHand = payments
    .filter((p) => p.mode === "Cash")
    .reduce((sum, p) => sum + p.amount, 0);
  const upiToday = payments
    .filter((p) => p.mode === "UPI" && p.date === today)
    .reduce((sum, p) => sum + p.amount, 0);
  const totalToday = payments
    .filter((p) => p.date === today)
    .reduce((sum, p) => sum + p.amount, 0);

  const handleDelete = (id) => {
    setPayments((prev) => prev.filter((p) => p.id !== id));
  };

  const handleAdd = (e) => {
    e.preventDefault();
    if (!form.date || !form.amount) return;
    setPayments((prev) => [
      { id: Date.now(), ...form, amount: Number(form.amount), ref: form.ref || "-" },
      ...prev,
    ]);
    setForm(emptyForm);
    setShowModal(false);
  };

  return (
    <Layout>
    <div className="text-white p-8">
      <div className="mb-8">
        <h1 className="text-2xl font-semibold">Payments / Bank</h1>
        <p className="text-sm text-gray-400 mt-1">Track cash, UPI and bank collections</p>
      </div>

      <div className="grid grid-cols-4 gap-5 mb-8">
        <StatCard label="Cash in hand" value={`₹${cashInHand.toLocaleString("en-IN")}`} />
        <StatCard label="UPI today" value={`₹${upiToday.toLocaleString("en-IN")}`} />
        <StatCard label="Bank balance" value="Not synced" />
        <StatCard label="Total collected today" value={`₹${totalToday.toLocaleString("en-IN")}`} />
      </div>

      <div className="bg-[#15151f] border border-[#2a2a3a] rounded-xl p-6">
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-lg font-medium">Payment records</h2>
          <div className="flex items-center gap-3">
            <select
              value={sourceFilter}
              onChange={(e) => setSourceFilter(e.target.value)}
              className="bg-[#0b0b12] border border-[#2a2a3a] text-sm rounded-lg px-3 py-2 text-gray-300"
            >
              {sources.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
            <select
              value={modeFilter}
              onChange={(e) => setModeFilter(e.target.value)}
              className="bg-[#0b0b12] border border-[#2a2a3a] text-sm rounded-lg px-3 py-2 text-gray-300"
            >
              {modes.map((m) => (
                <option key={m} value={m}>
                  {m}
                </option>
              ))}
            </select>
            <button
              onClick={() => setShowModal(true)}
              className="bg-gradient-to-r from-fuchsia-500 to-blue-500 text-white text-sm font-medium px-4 py-2 rounded-lg hover:opacity-90"
            >
              + Add Payment
            </button>
          </div>
        </div>

        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-gray-400 border-b border-[#2a2a3a]">
              <th className="py-3 font-normal">Date</th>
              <th className="py-3 font-normal">Source</th>
              <th className="py-3 font-normal">Mode</th>
              <th className="py-3 font-normal">Amount</th>
              <th className="py-3 font-normal">Reference No.</th>
              <th className="py-3 font-normal text-right">Action</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((p) => (
              <tr key={p.id} className="border-b border-[#20202c] last:border-0">
                <td className="py-4 text-gray-400">{p.date}</td>
                <td className="py-4 font-medium">{p.source}</td>
                <td className="py-4 text-gray-400">{p.mode}</td>
                <td className="py-4">₹{p.amount.toLocaleString("en-IN")}</td>
                <td className="py-4 text-gray-400">{p.ref}</td>
                <td className="py-4 text-right">
                  {p.source === "Manual" && (
                    <button
                      onClick={() => handleDelete(p.id)}
                      className="text-rose-400 hover:text-rose-300 font-medium"
                    >
                      Delete
                    </button>
                  )}
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr>
                <td colSpan={6} className="py-8 text-center text-gray-500">
                  No payment records match this filter.
                </td>
              </tr>
            )}
          </tbody>
        </table>
        <p className="text-xs text-gray-500 mt-4">
          Billing and Udhar records are auto-populated. Manual entries can be added and deleted here.
        </p>
      </div>

      {showModal && (
        <Modal title="Add Payment" onClose={() => setShowModal(false)}>
          <form onSubmit={handleAdd} className="space-y-4">
            <div>
              <label className="block text-sm text-gray-400 mb-2">Date</label>
              <input
                type="date"
                value={form.date}
                onChange={(e) => setForm({ ...form, date: e.target.value })}
                className="w-full bg-[#0b0b12] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-fuchsia-500"
                required
              />
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-2">Mode</label>
              <select
                value={form.mode}
                onChange={(e) => setForm({ ...form, mode: e.target.value })}
                className="w-full bg-[#0b0b12] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-white"
              >
                {formModes.map((m) => (
                  <option key={m} value={m}>
                    {m}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-2">Amount</label>
              <input
                type="number"
                value={form.amount}
                onChange={(e) => setForm({ ...form, amount: e.target.value })}
                className="w-full bg-[#0b0b12] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-fuchsia-500"
                placeholder="e.g. 500"
                required
              />
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-2">Reference No. (optional)</label>
              <input
                value={form.ref}
                onChange={(e) => setForm({ ...form, ref: e.target.value })}
                className="w-full bg-[#0b0b12] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-fuchsia-500"
                placeholder="e.g. UPI transaction ID"
              />
            </div>
            <div className="flex gap-3 pt-2">
              <button
                type="submit"
                className="flex-1 bg-gradient-to-r from-fuchsia-500 to-blue-500 text-white text-sm font-medium px-4 py-2 rounded-lg hover:opacity-90"
              >
                Add
              </button>
              <button
                type="button"
                onClick={() => setShowModal(false)}
                className="flex-1 bg-[#0b0b12] border border-[#2a2a3a] text-sm font-medium px-4 py-2 rounded-lg text-gray-300"
              >
                Cancel
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
    </Layout>
  );
}
