import React, { useState } from "react";
import Layout from "./Layout";
import Modal from "./Modal";


const initialPurchases = [
  { id: 1, supplier: "Reliance Distributors", date: "2026-08-01", item: "Groceries", amount: 5400, status: "Paid" },
  { id: 2, supplier: "Gupta Wholesale", date: "2026-07-29", item: "Dairy", amount: 2200, status: "Pending" },
  { id: 3, supplier: "Shree Traders", date: "2026-07-22", item: "Snacks", amount: 3800, status: "Pending" },
  { id: 4, supplier: "Patel Agro", date: "2026-08-05", item: "Grains", amount: 1500, status: "Paid" },
];

function StatCard({ label, value }) {
  return (
    <div className="bg-[#15151f] border border-[#2a2a3a] rounded-xl p-5">
      <p className="text-sm text-gray-400 mb-2">{label}</p>
      <p className="text-2xl font-semibold text-white">{value}</p>
    </div>
  );
}

function StatusPill({ status }) {
  const isPaid = status === "Paid";
  return (
    <span
      className={`px-3 py-1 rounded-full text-xs font-medium ${
        isPaid ? "bg-emerald-500/15 text-emerald-400" : "bg-rose-500/15 text-rose-400"
      }`}
    >
      {status}
    </span>
  );
}

const emptyForm = { supplier: "", date: "", item: "", amount: "" };

export default function Suppliers() {
  const [purchases, setPurchases] = useState(initialPurchases);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState(emptyForm);

  const totalPayable = purchases
    .filter((p) => p.status === "Pending")
    .reduce((sum, p) => sum + p.amount, 0);
  const pendingCount = purchases.filter((p) => p.status === "Pending").length;
  const paidThisMonth = purchases.filter((p) => p.status === "Paid").length;

  const markPaid = (id) => {
    setPurchases((prev) =>
      prev.map((p) => (p.id === id ? { ...p, status: "Paid" } : p))
    );
  };

  const handleAdd = (e) => {
    e.preventDefault();
    if (!form.supplier || !form.date || !form.amount) return;
    const newPurchase = {
      id: Date.now(),
      supplier: form.supplier,
      date: form.date,
      item: form.item || "-",
      amount: Number(form.amount),
      status: "Pending",
    };
    setPurchases((prev) => [newPurchase, ...prev]);
    setForm(emptyForm);
    setShowModal(false);
  };

  return (
    <Layout>
    <div className="text-white p-8">
      <div className="mb-8">
        <h1 className="text-2xl font-semibold">Suppliers / Purchases</h1>
        <p className="text-sm text-gray-400 mt-1">Track stock purchases and supplier payments</p>
      </div>

      <div className="grid grid-cols-4 gap-5 mb-8">
        <StatCard label="Total payable" value={`₹${totalPayable.toLocaleString("en-IN")}`} />
        <StatCard label="Pending suppliers" value={pendingCount} />
        <StatCard label="Total records" value={purchases.length} />
        <StatCard label="Paid this month" value={paidThisMonth} />
      </div>

      <div className="bg-[#15151f] border border-[#2a2a3a] rounded-xl p-6">
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-lg font-medium">Purchase records</h2>
          <button
            onClick={() => setShowModal(true)}
            className="bg-gradient-to-r from-fuchsia-500 to-blue-500 text-white text-sm font-medium px-4 py-2 rounded-lg hover:opacity-90"
          >
            + Add Purchase
          </button>
        </div>

        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-gray-400 border-b border-[#2a2a3a]">
              <th className="py-3 font-normal">Supplier</th>
              <th className="py-3 font-normal">Date</th>
              <th className="py-3 font-normal">Item / Category</th>
              <th className="py-3 font-normal">Amount</th>
              <th className="py-3 font-normal">Status</th>
              <th className="py-3 font-normal text-right">Action</th>
            </tr>
          </thead>
          <tbody>
            {purchases.map((p) => (
              <tr key={p.id} className="border-b border-[#20202c] last:border-0">
                <td className="py-4 font-medium">{p.supplier}</td>
                <td className="py-4 text-gray-400">{p.date}</td>
                <td className="py-4 text-gray-400">{p.item}</td>
                <td className="py-4">₹{p.amount.toLocaleString("en-IN")}</td>
                <td className="py-4">
                  <StatusPill status={p.status} />
                </td>
                <td className="py-4 text-right">
                  {p.status === "Pending" && (
                    <button
                      onClick={() => markPaid(p.id)}
                      className="text-blue-400 hover:text-blue-300 font-medium"
                    >
                      Mark paid
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showModal && (
        <Modal title="Add Purchase" onClose={() => setShowModal(false)}>
          <form onSubmit={handleAdd} className="space-y-4">
            <div>
              <label className="block text-sm text-gray-400 mb-2">Supplier name</label>
              <input
                value={form.supplier}
                onChange={(e) => setForm({ ...form, supplier: e.target.value })}
                className="w-full bg-[#0b0b12] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-fuchsia-500"
                placeholder="e.g. Reliance Distributors"
                required
              />
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-2">Purchase date</label>
              <input
                type="date"
                value={form.date}
                onChange={(e) => setForm({ ...form, date: e.target.value })}
                className="w-full bg-[#0b0b12] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-fuchsia-500"
                required
              />
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-2">Item / Category</label>
              <input
                value={form.item}
                onChange={(e) => setForm({ ...form, item: e.target.value })}
                className="w-full bg-[#0b0b12] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-fuchsia-500"
                placeholder="e.g. Groceries"
              />
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-2">Amount</label>
              <input
                type="number"
                value={form.amount}
                onChange={(e) => setForm({ ...form, amount: e.target.value })}
                className="w-full bg-[#0b0b12] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-fuchsia-500"
                placeholder="e.g. 2500"
                required
              />
            </div>
            <div className="flex gap-3 pt-2">
              <button
                type="submit"
                className="flex-1 bg-gradient-to-r from-fuchsia-500 to-blue-500 text-white text-sm font-medium px-4 py-2 rounded-lg hover:opacity-90"
              >
                Add
              </button>
              <button
                type="button"
                onClick={() => setShowModal(false)}
                className="flex-1 bg-[#0b0b12] border border-[#2a2a3a] text-sm font-medium px-4 py-2 rounded-lg text-gray-300"
              >
                Cancel
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
    </Layout>
  );
}
