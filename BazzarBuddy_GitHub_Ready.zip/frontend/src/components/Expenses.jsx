import React, { useState } from "react";
import Layout from "./Layout";
import Modal from "./Modal";

const initialExpenses = [
  { id: 1, title: "Shop Rent", category: "Rent", date: "2026-08-01", amount: 12000, mode: "Bank" },
  { id: 2, title: "Electricity Bill", category: "Electricity", date: "2026-08-03", amount: 2400, mode: "UPI" },
  { id: 3, title: "Staff Salary - Raju", category: "Salary", date: "2026-08-05", amount: 9000, mode: "Cash" },
  { id: 4, title: "Packaging Material", category: "Misc", date: "2026-08-06", amount: 850, mode: "Cash" },
];

const categories = ["All", "Rent", "Salary", "Electricity", "Misc"];
const formCategories = ["Rent", "Salary", "Electricity", "Misc"];
const modes = ["Cash", "UPI", "Bank", "Card"];

function StatCard({ label, value }) {
  return (
    <div className="bg-[#15151f] border border-[#2a2a3a] rounded-xl p-5">
      <p className="text-sm text-gray-400 mb-2">{label}</p>
      <p className="text-2xl font-semibold text-white">{value}</p>
    </div>
  );
}

const emptyForm = { title: "", category: "Rent", date: "", amount: "", mode: "Cash" };

export default function Expenses() {
  const [expenses, setExpenses] = useState(initialExpenses);
  const [filter, setFilter] = useState("All");
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(emptyForm);

  const filtered = filter === "All" ? expenses : expenses.filter((e) => e.category === filter);

  const total = expenses.reduce((sum, e) => sum + e.amount, 0);
  const categoryTotals = expenses.reduce((acc, e) => {
    acc[e.category] = (acc[e.category] || 0) + e.amount;
    return acc;
  }, {});
  const biggestCategory = Object.entries(categoryTotals).sort((a, b) => b[1] - a[1])[0]?.[0] || "-";
  const lastExpenseDate = expenses.reduce((latest, e) => (e.date > latest ? e.date : latest), "");

  const openAddModal = () => {
    setEditingId(null);
    setForm(emptyForm);
    setShowModal(true);
  };

  const openEditModal = (expense) => {
    setEditingId(expense.id);
    setForm({
      title: expense.title,
      category: expense.category,
      date: expense.date,
      amount: expense.amount,
      mode: expense.mode,
    });
    setShowModal(true);
  };

  const handleDelete = (id) => {
    setExpenses((prev) => prev.filter((e) => e.id !== id));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.title || !form.date || !form.amount) return;

    if (editingId) {
      setExpenses((prev) =>
        prev.map((exp) =>
          exp.id === editingId
            ? { ...exp, ...form, amount: Number(form.amount) }
            : exp
        )
      );
    } else {
      setExpenses((prev) => [
        { id: Date.now(), ...form, amount: Number(form.amount) },
        ...prev,
      ]);
    }
    setShowModal(false);
    setForm(emptyForm);
    setEditingId(null);
  };

  return (
    <Layout>
    <div className="text-white p-8">
      <div className="mb-8">
        <h1 className="text-2xl font-semibold">Expenses</h1>
        <p className="text-sm text-gray-400 mt-1">Track shop expenses like rent, salary and bills</p>
      </div>

      <div className="grid grid-cols-4 gap-5 mb-8">
        <StatCard label="Total expenses (month)" value={`₹${total.toLocaleString("en-IN")}`} />
        <StatCard label="Categories" value={Object.keys(categoryTotals).length} />
        <StatCard label="Biggest category" value={biggestCategory} />
        <StatCard label="Last expense date" value={lastExpenseDate} />
      </div>

      <div className="bg-[#15151f] border border-[#2a2a3a] rounded-xl p-6">
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-lg font-medium">Expense records</h2>
          <div className="flex items-center gap-3">
            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="bg-[#0b0b12] border border-[#2a2a3a] text-sm rounded-lg px-3 py-2 text-gray-300"
            >
              {categories.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
            <button
              onClick={openAddModal}
              className="bg-gradient-to-r from-fuchsia-500 to-blue-500 text-white text-sm font-medium px-4 py-2 rounded-lg hover:opacity-90"
            >
              + Add Expense
            </button>
          </div>
        </div>

        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-gray-400 border-b border-[#2a2a3a]">
              <th className="py-3 font-normal">Title</th>
              <th className="py-3 font-normal">Category</th>
              <th className="py-3 font-normal">Date</th>
              <th className="py-3 font-normal">Amount</th>
              <th className="py-3 font-normal">Payment mode</th>
              <th className="py-3 font-normal text-right">Action</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((e) => (
              <tr key={e.id} className="border-b border-[#20202c] last:border-0">
                <td className="py-4 font-medium">{e.title}</td>
                <td className="py-4 text-gray-400">{e.category}</td>
                <td className="py-4 text-gray-400">{e.date}</td>
                <td className="py-4">₹{e.amount.toLocaleString("en-IN")}</td>
                <td className="py-4 text-gray-400">{e.mode}</td>
                <td className="py-4 text-right">
                  <button
                    onClick={() => openEditModal(e)}
                    className="text-blue-400 hover:text-blue-300 font-medium mr-3"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDelete(e.id)}
                    className="text-rose-400 hover:text-rose-300 font-medium"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showModal && (
        <Modal title={editingId ? "Edit Expense" : "Add Expense"} onClose={() => setShowModal(false)}>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm text-gray-400 mb-2">Title</label>
              <input
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
                className="w-full bg-[#0b0b12] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-fuchsia-500"
                placeholder="e.g. Shop Rent"
                required
              />
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-2">Category</label>
              <select
                value={form.category}
                onChange={(e) => setForm({ ...form, category: e.target.value })}
                className="w-full bg-[#0b0b12] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-white"
              >
                {formCategories.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-2">Date</label>
              <input
                type="date"
                value={form.date}
                onChange={(e) => setForm({ ...form, date: e.target.value })}
                className="w-full bg-[#0b0b12] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-fuchsia-500"
                required
              />
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-2">Amount</label>
              <input
                type="number"
                value={form.amount}
                onChange={(e) => setForm({ ...form, amount: e.target.value })}
                className="w-full bg-[#0b0b12] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-fuchsia-500"
                placeholder="e.g. 1200"
                required
              />
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-2">Payment mode</label>
              <select
                value={form.mode}
                onChange={(e) => setForm({ ...form, mode: e.target.value })}
                className="w-full bg-[#0b0b12] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-white"
              >
                {modes.map((m) => (
                  <option key={m} value={m}>
                    {m}
                  </option>
                ))}
              </select>
            </div>
            <div className="flex gap-3 pt-2">
              <button
                type="submit"
                className="flex-1 bg-gradient-to-r from-fuchsia-500 to-blue-500 text-white text-sm font-medium px-4 py-2 rounded-lg hover:opacity-90"
              >
                {editingId ? "Save changes" : "Add"}
              </button>
              <button
                type="button"
                onClick={() => setShowModal(false)}
                className="flex-1 bg-[#0b0b12] border border-[#2a2a3a] text-sm font-medium px-4 py-2 rounded-lg text-gray-300"
              >
                Cancel
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
    </Layout>
  );
}
