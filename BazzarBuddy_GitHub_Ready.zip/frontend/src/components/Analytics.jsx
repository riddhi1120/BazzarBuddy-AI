import React, { useState } from 'react';
import Sidebar from './Sidebar';

const weeklyTrend = [
  { day: 'Mon', sales: 14200, profit: 3200 },
  { day: 'Tue', sales: 16800, profit: 3800 },
  { day: 'Wed', sales: 15100, profit: 3400 },
  { day: 'Thu', sales: 18900, profit: 4300 },
  { day: 'Fri', sales: 21400, profit: 5100 },
  { day: 'Sat', sales: 26800, profit: 6200 },
  { day: 'Sun', sales: 19200, profit: 4500 },
];

const topProducts = [
  { id: 1, name: 'Tea powder', units: 142, revenue: 13490 },
  { id: 2, name: 'Rice (25kg)', units: 98, revenue: 112700 },
  { id: 3, name: 'Soap bars', units: 87, revenue: 3045 },
  { id: 4, name: 'Sugar (1kg)', units: 76, revenue: 3420 },
  { id: 5, name: 'Cooking oil (1L)', units: 54, revenue: 7560 },
];

function TopBar() {
  return (
    <header className="w-full flex items-center justify-between px-6 py-4 border-b border-white/10 bg-black/30 backdrop-blur-md">
      <div>
        <h1 className="text-lg font-semibold text-white">Analytics</h1>
        <p className="text-xs text-slate-400">Deep insights into your store's performance</p>
      </div>
      <div className="flex items-center gap-4">
        <button className="text-slate-300 hover:text-cyan-300 transition-colors duration-200">🔔</button>
        <div className="w-8 h-8 rounded-full bg-gradient-to-r from-cyan-500 to-fuchsia-500 flex items-center justify-center text-xs font-medium text-white">
          RS
        </div>
      </div>
    </header>
  );
}

function StatCard({ label, value, trend }) {
  return (
    <div className="bg-white/5 border border-white/10 rounded-xl p-4 hover:border-cyan-400/40 hover:shadow-[0_0_15px_rgba(34,211,238,0.2)] transition-all duration-200">
      <p className="text-xs text-slate-400 mb-1">{label}</p>
      <div className="flex items-baseline gap-2">
        <p className="text-xl font-semibold text-white">{value}</p>
        {trend && <span className="text-xs text-emerald-400">{trend}</span>}
      </div>
    </div>
  );
}

function TrendChart() {
  const [metric, setMetric] = useState('sales');
  const [hoverIndex, setHoverIndex] = useState(null);
  const maxValue = Math.max(...weeklyTrend.map((d) => d[metric]));

  return (
    <div className="bg-white/5 border border-white/10 rounded-xl p-4 hover:border-cyan-400/30 transition-all duration-200">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold text-white">Weekly performance</h3>
        <div className="flex gap-2 bg-white/5 border border-white/10 rounded-lg p-1">
          {['sales', 'profit'].map((m) => (
            <button
              key={m}
              onClick={() => setMetric(m)}
              className={`px-3 py-1 rounded-md text-xs font-medium capitalize transition-all duration-200 ${
                metric === m
                  ? 'bg-gradient-to-r from-cyan-500 to-fuchsia-500 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {m}
            </button>
          ))}
        </div>
      </div>
      <div className="flex items-end justify-between gap-3 h-44">
        {weeklyTrend.map((d, i) => (
          <div
            key={d.day}
            className="flex flex-col items-center flex-1 gap-2 h-full justify-end relative"
            onMouseEnter={() => setHoverIndex(i)}
            onMouseLeave={() => setHoverIndex(null)}
          >
            {hoverIndex === i && (
              <div className="absolute -top-8 bg-[#1e1e2e] border border-cyan-400/30 text-white text-xs px-2 py-1 rounded-md whitespace-nowrap z-10">
                ₹{d[metric].toLocaleString('en-IN')}
              </div>
            )}
            <div
              className={`w-full rounded-t-md transition-all duration-200 cursor-pointer ${
                hoverIndex === i ? 'bg-gradient-to-t from-fuchsia-500 to-cyan-400' : 'bg-gradient-to-t from-cyan-500 to-fuchsia-500 opacity-80'
              }`}
              style={{ height: `${(d[metric] / maxValue) * 100}%` }}
            ></div>
            <span className="text-xs text-slate-400">{d.day}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function TopProductsList() {
  const maxRevenue = Math.max(...topProducts.map((p) => p.revenue));
  return (
    <div className="bg-white/5 border border-white/10 rounded-xl p-4 hover:border-fuchsia-400/30 transition-all duration-200">
      <h3 className="text-sm font-semibold text-white mb-3">Top products by revenue</h3>
      <ul className="flex flex-col gap-3">
        {topProducts.map((p) => (
          <li key={p.id}>
            <div className="flex justify-between text-sm mb-1">
              <span className="text-slate-300">{p.name}</span>
              <span className="text-slate-200 font-medium">₹{p.revenue.toLocaleString('en-IN')}</span>
            </div>
            <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-cyan-500 to-fuchsia-500"
                style={{ width: `${(p.revenue / maxRevenue) * 100}%` }}
              ></div>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">{p.units} units sold</p>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default function Analytics() {
  const weekTotal = weeklyTrend.reduce((sum, d) => sum + d.sales, 0);
  const weekProfit = weeklyTrend.reduce((sum, d) => sum + d.profit, 0);
  const margin = ((weekProfit / weekTotal) * 100).toFixed(1);

  const summaryStats = [
    { label: 'Week sales', value: `₹${weekTotal.toLocaleString('en-IN')}`, trend: '+8.2%' },
    { label: 'Week profit', value: `₹${weekProfit.toLocaleString('en-IN')}`, trend: '+5.4%' },
    { label: 'Profit margin', value: `${margin}%` },
    { label: 'Best day', value: 'Saturday' },
  ];

  return (
    <div className="w-full min-h-screen bg-[#0a0a12] flex">
      <Sidebar />
      <div className="flex-1 flex flex-col">
        <TopBar />
        <main className="p-6 flex-1">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
            {summaryStats.map((s) => (
              <StatCard key={s.label} label={s.label} value={s.value} trend={s.trend} />
            ))}
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-[1.3fr_1fr] gap-4">
            <TrendChart />
            <TopProductsList />
          </div>
        </main>
      </div>
    </div>
  );
}