import React, { useState } from "react";
import Layout from "./Layout";
import Modal from "./Modal";

const initialStaff = [
  { id: 1, name: "Rajesh Sharma", role: "Owner", phone: "98765 43210", lastActive: "Today, 9:12 AM", status: "Active" },
  { id: 2, name: "Priya Mehta", role: "Cashier", phone: "98123 45678", lastActive: "Today, 8:45 AM", status: "Active" },
  { id: 3, name: "Raju Verma", role: "Manager", phone: "97654 32109", lastActive: "Yesterday", status: "Active" },
  { id: 4, name: "Sunil Rana", role: "Cashier", phone: "96543 21098", lastActive: "3 days ago", status: "Blocked" },
];

const roles = ["Owner", "Manager", "Cashier"];

function StatCard({ label, value }) {
  return (
    <div className="bg-[#15151f] border border-[#2a2a3a] rounded-xl p-5">
      <p className="text-sm text-gray-400 mb-2">{label}</p>
      <p className="text-2xl font-semibold text-white">{value}</p>
    </div>
  );
}

function StatusPill({ status }) {
  const isActive = status === "Active";
  return (
    <span
      className={`px-3 py-1 rounded-full text-xs font-medium ${
        isActive ? "bg-emerald-500/15 text-emerald-400" : "bg-rose-500/15 text-rose-400"
      }`}
    >
      {status}
    </span>
  );
}

const emptyForm = { name: "", role: "Cashier", phone: "" };

export default function Staff() {
  const [staff, setStaff] = useState(initialStaff);
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(emptyForm);

  const activeToday = staff.filter((s) => s.lastActive.startsWith("Today")).length;
  const roleCount = new Set(staff.map((s) => s.role)).size;

  const toggleStatus = (id) => {
    setStaff((prev) =>
      prev.map((s) =>
        s.id === id ? { ...s, status: s.status === "Active" ? "Blocked" : "Active" } : s
      )
    );
  };

  const openAddModal = () => {
    setEditingId(null);
    setForm(emptyForm);
    setShowModal(true);
  };

  const openEditModal = (member) => {
    setEditingId(member.id);
    setForm({ name: member.name, role: member.role, phone: member.phone });
    setShowModal(true);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.name || !form.phone) return;

    if (editingId) {
      setStaff((prev) =>
        prev.map((s) => (s.id === editingId ? { ...s, ...form } : s))
      );
    } else {
      setStaff((prev) => [
        { id: Date.now(), ...form, lastActive: "Just added", status: "Active" },
        ...prev,
      ]);
    }
    setShowModal(false);
    setForm(emptyForm);
    setEditingId(null);
  };

  return (
    <Layout>
    <div className="text-white p-8">
      <div className="mb-8">
        <h1 className="text-2xl font-semibold">Staff / Users</h1>
        <p className="text-sm text-gray-400 mt-1">Manage staff access and roles</p>
      </div>

      <div className="grid grid-cols-3 gap-5 mb-8">
        <StatCard label="Total staff" value={staff.length} />
        <StatCard label="Active today" value={activeToday} />
        <StatCard label="Roles" value={roleCount} />
      </div>

      <div className="bg-[#15151f] border border-[#2a2a3a] rounded-xl p-6">
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-lg font-medium">Staff members</h2>
          <button
            onClick={openAddModal}
            className="bg-gradient-to-r from-fuchsia-500 to-blue-500 text-white text-sm font-medium px-4 py-2 rounded-lg hover:opacity-90"
          >
            + Add Staff
          </button>
        </div>

        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-gray-400 border-b border-[#2a2a3a]">
              <th className="py-3 font-normal">Name</th>
              <th className="py-3 font-normal">Role</th>
              <th className="py-3 font-normal">Phone</th>
              <th className="py-3 font-normal">Last active</th>
              <th className="py-3 font-normal">Status</th>
              <th className="py-3 font-normal text-right">Action</th>
            </tr>
          </thead>
          <tbody>
            {staff.map((s) => (
              <tr key={s.id} className="border-b border-[#20202c] last:border-0">
                <td className="py-4 font-medium">{s.name}</td>
                <td className="py-4 text-gray-400">{s.role}</td>
                <td className="py-4 text-gray-400">{s.phone}</td>
                <td className="py-4 text-gray-400">{s.lastActive}</td>
                <td className="py-4">
                  <StatusPill status={s.status} />
                </td>
                <td className="py-4 text-right">
                  <button
                    onClick={() => openEditModal(s)}
                    className="text-blue-400 hover:text-blue-300 font-medium mr-3"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => toggleStatus(s.id)}
                    className="text-rose-400 hover:text-rose-300 font-medium"
                  >
                    {s.status === "Active" ? "Block" : "Unblock"}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showModal && (
        <Modal title={editingId ? "Edit Staff" : "Add Staff"} onClose={() => setShowModal(false)}>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm text-gray-400 mb-2">Name</label>
              <input
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                className="w-full bg-[#0b0b12] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-fuchsia-500"
                placeholder="e.g. Priya Mehta"
                required
              />
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-2">Role</label>
              <select
                value={form.role}
                onChange={(e) => setForm({ ...form, role: e.target.value })}
                className="w-full bg-[#0b0b12] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-white"
              >
                {roles.map((r) => (
                  <option key={r} value={r}>
                    {r}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-2">Phone</label>
              <input
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
                className="w-full bg-[#0b0b12] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-fuchsia-500"
                placeholder="e.g. 98765 43210"
                required
              />
            </div>
            <div className="flex gap-3 pt-2">
              <button
                type="submit"
                className="flex-1 bg-gradient-to-r from-fuchsia-500 to-blue-500 text-white text-sm font-medium px-4 py-2 rounded-lg hover:opacity-90"
              >
                {editingId ? "Save changes" : "Add"}
              </button>
              <button
                type="button"
                onClick={() => setShowModal(false)}
                className="flex-1 bg-[#0b0b12] border border-[#2a2a3a] text-sm font-medium px-4 py-2 rounded-lg text-gray-300"
              >
                Cancel
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
    </Layout>
  );
}
