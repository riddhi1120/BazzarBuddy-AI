import React, { useState } from "react";
import Layout from "./Layout";

const tabs = ["Shop Profile", "Tax / GST", "Invoice", "Preferences", "Backup"];

function Field({ label, placeholder, defaultValue, type = "text" }) {
  return (
    <div className="mb-4">
      <label className="block text-sm text-gray-400 mb-2">{label}</label>
      <input
        type={type}
        defaultValue={defaultValue}
        placeholder={placeholder}
        className="w-full bg-[#0b0b12] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-fuchsia-500"
      />
    </div>
  );
}

export default function Settings() {
  const [active, setActive] = useState("Shop Profile");
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <Layout>
    <div className="text-white p-8">
      <div className="mb-8">
        <h1 className="text-2xl font-semibold">Settings</h1>
        <p className="text-sm text-gray-400 mt-1">Manage your shop profile, tax details and preferences</p>
      </div>

      <div className="flex gap-6">
        <div className="w-56 shrink-0">
          <div className="bg-[#15151f] border border-[#2a2a3a] rounded-xl p-2">
            {tabs.map((tab) => (
              <button
                key={tab}
                onClick={() => setActive(tab)}
                className={`w-full text-left px-4 py-3 rounded-lg text-sm mb-1 last:mb-0 ${
                  active === tab
                    ? "bg-gradient-to-r from-fuchsia-500/20 to-blue-500/20 text-white font-medium"
                    : "text-gray-400 hover:bg-[#20202c]"
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        <div className="flex-1 bg-[#15151f] border border-[#2a2a3a] rounded-xl p-6">
          {active === "Shop Profile" && (
            <>
              <Field label="Shop name" placeholder="e.g. Sharma General Store" />
              <Field label="Owner name" placeholder="e.g. Rajesh Sharma" />
              <Field label="Phone number" placeholder="e.g. 98765 43210" />
              <Field label="Address" placeholder="Shop address" />
              <div className="mb-4">
                <label className="block text-sm text-gray-400 mb-2">Shop logo</label>
                <button className="bg-[#0b0b12] border border-[#2a2a3a] rounded-lg px-4 py-2 text-sm text-gray-300 hover:border-fuchsia-500">
                  Upload logo
                </button>
              </div>
            </>
          )}

          {active === "Tax / GST" && (
            <>
              <Field label="GST number" placeholder="e.g. 24ABCDE1234F1Z5" />
              <Field label="Default tax rate (%)" placeholder="e.g. 5" />
              <Field label="Invoice prefix" placeholder="e.g. INV-" />
            </>
          )}

          {active === "Invoice" && (
            <>
              <div className="mb-4">
                <label className="block text-sm text-gray-400 mb-2">Paper size</label>
                <select className="w-full bg-[#0b0b12] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-white">
                  <option>A4</option>
                  <option>Thermal 80mm</option>
                  <option>Thermal 58mm</option>
                </select>
              </div>
              <Field label="Invoice footer note" placeholder="e.g. Thank you for shopping with us!" />
              <div className="mb-4">
                <label className="block text-sm text-gray-400 mb-2">Printer</label>
                <select className="w-full bg-[#0b0b12] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-white">
                  <option>Default printer</option>
                </select>
              </div>
            </>
          )}

          {active === "Preferences" && (
            <>
              <div className="mb-4">
                <label className="block text-sm text-gray-400 mb-2">Currency</label>
                <select className="w-full bg-[#0b0b12] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-white">
                  <option>₹ Indian Rupee</option>
                  <option>$ US Dollar</option>
                </select>
              </div>
              <div className="mb-4">
                <label className="block text-sm text-gray-400 mb-2">Language</label>
                <select className="w-full bg-[#0b0b12] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-white">
                  <option>English</option>
                  <option>Gujarati</option>
                  <option>Hindi</option>
                </select>
              </div>
              <div className="mb-4">
                <label className="block text-sm text-gray-400 mb-2">Date format</label>
                <select className="w-full bg-[#0b0b12] border border-[#2a2a3a] rounded-lg px-3 py-2 text-sm text-white">
                  <option>YYYY-MM-DD</option>
                  <option>DD-MM-YYYY</option>
                </select>
              </div>
            </>
          )}

          {active === "Backup" && (
            <div className="flex gap-3">
              <button
                onClick={() => {
                  const blob = new Blob(
                    [JSON.stringify({ exportedAt: new Date().toISOString() }, null, 2)],
                    { type: "application/json" }
                  );
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement("a");
                  a.href = url;
                  a.download = "bazaarbuddy-backup.json";
                  a.click();
                  URL.revokeObjectURL(url);
                }}
                className="bg-gradient-to-r from-fuchsia-500 to-blue-500 text-white text-sm font-medium px-4 py-2 rounded-lg hover:opacity-90"
              >
                Export data
              </button>
              <label className="bg-[#0b0b12] border border-[#2a2a3a] text-sm font-medium px-4 py-2 rounded-lg text-gray-300 hover:border-fuchsia-500 cursor-pointer">
                Import data
                <input
                  type="file"
                  accept="application/json"
                  className="hidden"
                  onChange={(e) => {
                    if (e.target.files?.[0]) {
                      alert(`Selected file: ${e.target.files[0].name}`);
                    }
                  }}
                />
              </label>
            </div>
          )}

          <button
            onClick={handleSave}
            className="mt-4 bg-gradient-to-r from-fuchsia-500 to-blue-500 text-white text-sm font-medium px-5 py-2 rounded-lg hover:opacity-90"
          >
            {saved ? "Saved ✓" : "Save changes"}
          </button>
        </div>
      </div>
    </div>
    </Layout>
  );
}
