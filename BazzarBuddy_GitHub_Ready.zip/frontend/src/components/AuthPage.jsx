import React, { useState } from 'react';

export default function AuthPage({ onAuthSuccess }) {
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
  });

  const handleChange = (field) => (e) => {
    setFormData((prev) => ({ ...prev, [field]: e.target.value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (isLogin) {
      // e.g. call your /api/login endpoint with { email, password }
      console.log('Logging in with', {
        email: formData.email,
        password: formData.password,
      });
      onAuthSuccess('Logged in successfully!');
    } else {
      // e.g. call your /api/signup endpoint with the full formData
      console.log('Signing up with', formData);
      onAuthSuccess('Your account has been created successfully!');
    }
  };

  return (
    <div className="w-full min-h-screen bg-[#0a0a12] flex items-center justify-center px-6 py-12 relative overflow-hidden">
      <div className="pointer-events-none absolute top-[-100px] left-1/4 w-80 h-80 bg-cyan-500/25 rounded-full blur-[100px]" />
      <div className="pointer-events-none absolute bottom-[-100px] right-1/4 w-96 h-96 bg-fuchsia-500/25 rounded-full blur-[110px]" />

      <div className="relative w-full max-w-md">
        <div className="flex items-center justify-center gap-2 mb-8">
          <div className="w-9 h-9 rounded-lg bg-cyan-500/10 border border-cyan-400/30 flex items-center justify-center shadow-[0_0_15px_rgba(34,211,238,0.35)]">
            🛒
          </div>
          <span className="font-semibold text-white text-base tracking-wide">BazaarBuddy AI</span>
        </div>

        <div className="bg-white/5 border border-white/10 backdrop-blur-md rounded-2xl p-8 shadow-[0_0_40px_rgba(0,0,0,0.4)]">
          <div className="flex bg-black/30 border border-white/10 rounded-lg p-1 mb-7">
            <button
              type="button"
              onClick={() => setIsLogin(true)}
              className={`flex-1 text-sm py-2 rounded-md font-medium transition-all duration-200 ${
                isLogin
                  ? 'bg-gradient-to-r from-cyan-500 to-fuchsia-500 text-white shadow-[0_0_15px_rgba(217,70,239,0.35)]'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Log in
            </button>
            <button
              type="button"
              onClick={() => setIsLogin(false)}
              className={`flex-1 text-sm py-2 rounded-md font-medium transition-all duration-200 ${
                !isLogin
                  ? 'bg-gradient-to-r from-cyan-500 to-fuchsia-500 text-white shadow-[0_0_15px_rgba(217,70,239,0.35)]'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Create account
            </button>
          </div>

          <h1 className="text-xl font-semibold text-white mb-1.5">
            {isLogin ? 'Welcome back' : 'Create your account'}
          </h1>
          <p className="text-sm text-slate-400 mb-6">
            {isLogin ? 'Log in to your BazaarBuddy AI dashboard' : 'Start managing your kirana store smarter'}
          </p>

          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            {!isLogin && (
              <Field
                label="Full name"
                type="text"
                placeholder="e.g. Riddhi Sharma"
                value={formData.name}
                onChange={handleChange('name')}
              />
            )}

            <Field
              label={isLogin ? 'Email or phone' : 'Email'}
              type="text"
              placeholder="you@example.com"
              value={formData.email}
              onChange={handleChange('email')}
            />

            {!isLogin && (
              <Field
                label="Phone number"
                type="tel"
                placeholder="+91 98765 43210"
                value={formData.phone}
                onChange={handleChange('phone')}
              />
            )}

            <Field
              label="Password"
              type="password"
              placeholder="••••••••"
              value={formData.password}
              onChange={handleChange('password')}
            />

            {!isLogin && (
              <Field
                label="Confirm password"
                type="password"
                placeholder="••••••••"
                value={formData.confirmPassword}
                onChange={handleChange('confirmPassword')}
              />
            )}

            {isLogin && (
              <div className="flex justify-end -mt-1">
                <a href="#" className="text-xs text-cyan-300 hover:text-cyan-200 transition-colors duration-200">
                  Forgot password?
                </a>
              </div>
            )}

            <button
              type="submit"
              className="w-full mt-2 py-3 rounded-lg bg-gradient-to-r from-cyan-500 to-fuchsia-500 text-white text-sm font-semibold hover:shadow-[0_0_25px_rgba(217,70,239,0.55)] hover:scale-[1.02] transition-all duration-200"
            >
              {isLogin ? 'Log in' : 'Create account'}
            </button>
          </form>

          <p className="text-xs text-slate-400 text-center mt-6">
            {isLogin ? "Don't have an account? " : 'Already have an account? '}
            <button
              type="button"
              onClick={() => setIsLogin(!isLogin)}
              className="text-cyan-300 hover:text-cyan-200 font-medium transition-colors duration-200"
            >
              {isLogin ? 'Sign up' : 'Log in'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}

function Field({ label, type, placeholder, value, onChange }) {
  return (
    <div>
      <label className="block text-xs text-slate-300 mb-1.5">{label}</label>
      <input
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        className="w-full bg-black/30 border border-white/10 rounded-lg px-3.5 py-2.5 text-sm text-white placeholder:text-slate-500 outline-none focus:border-cyan-400/50 focus:shadow-[0_0_12px_rgba(34,211,238,0.25)] transition-all duration-200"
      />
    </div>
  );
}