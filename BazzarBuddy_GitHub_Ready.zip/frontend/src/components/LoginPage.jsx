import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

const AUTH_KEY = 'bazaarbuddy_auth';

export default function LoginPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const [mode, setMode] = useState('login');
  const [form, setForm] = useState({ name: '', email: '', phone: '', password: '', confirm: '' });
  const [error, setError] = useState('');

  const change = (key) => (e) => setForm((p) => ({ ...p, [key]: e.target.value }));

  const submit = (e) => {
    e.preventDefault();
    setError('');

    if (!form.email.trim() || !form.password.trim()) {
      setError('Please enter your email/phone and password.');
      return;
    }
    if (mode === 'signup') {
      if (!form.name.trim()) return setError('Please enter your name.');
      if (form.password.length < 4) return setError('Password should be at least 4 characters.');
      if (form.password !== form.confirm) return setError('Passwords do not match.');
      localStorage.setItem('bazaarbuddy_account', JSON.stringify({ name: form.name, email: form.email, phone: form.phone, password: form.password }));
    }

    const account = JSON.parse(localStorage.getItem('bazaarbuddy_account') || 'null');
    if (mode === 'login' && account) {
      const identifier = form.email.trim().toLowerCase();
      const accountEmail = String(account.email || '').trim().toLowerCase();
      const accountPhone = String(account.phone || '').replace(/\D/g, '');
      const enteredPhone = form.email.replace(/\D/g, '');
      const identifierMatches = identifier === accountEmail || (enteredPhone && enteredPhone === accountPhone);
      if (!identifierMatches || account.password !== form.password) {
        setError('Incorrect email/phone or password.');
        return;
      }
    }

    const user = account || { name: form.name || 'Store Owner', email: form.email, phone: form.phone };
    localStorage.setItem(AUTH_KEY, JSON.stringify({ ...user, loggedIn: true }));
    const destination = location.state?.from && location.state.from !== '/login' ? location.state.from : '/dashboard';
    navigate(destination, { replace: true });
  };

  return (
    <div className="login-page">
      <div className="login-glow login-glow-one" />
      <div className="login-glow login-glow-two" />
      <div className="login-card">
        <div className="login-brand"><span className="login-logo">🛍️</span><span>BazaarBuddy AI</span></div>
        <div className="login-tabs">
          <button className={mode === 'login' ? 'selected' : ''} onClick={() => setMode('login')}>Log in</button>
          <button className={mode === 'signup' ? 'selected' : ''} onClick={() => setMode('signup')}>Create account</button>
        </div>
        <h1>{mode === 'login' ? 'Welcome back' : 'Create your account'}</h1>
        <p className="login-sub">{mode === 'login' ? 'Log in to manage your kirana store.' : 'Start managing your kirana store smarter.'}</p>
        <form onSubmit={submit}>
          {mode === 'signup' && <label>Full name<input value={form.name} onChange={change('name')} placeholder="Your name" /></label>}
          <label>{mode === 'login' ? 'Email or phone' : 'Email'}<input value={form.email} onChange={change('email')} placeholder={mode === 'login' ? 'you@example.com or phone' : 'you@example.com'} /></label>
          {mode === 'signup' && <label>Phone number<input value={form.phone} onChange={change('phone')} placeholder="98765 43210" /></label>}
          <label>Password<input type="password" value={form.password} onChange={change('password')} placeholder="••••••••" /></label>
          {mode === 'signup' && <label>Confirm password<input type="password" value={form.confirm} onChange={change('confirm')} placeholder="••••••••" /></label>}
          {error && <div className="login-error">{error}</div>}
          <button className="login-submit" type="submit">{mode === 'login' ? 'Log in' : 'Create account'}</button>
        </form>
        <p className="login-switch">{mode === 'login' ? "Don't have an account?" : 'Already have an account?'} <button onClick={() => setMode(mode === 'login' ? 'signup' : 'login')}>{mode === 'login' ? 'Sign up' : 'Log in'}</button></p>
        {mode === 'login' && !localStorage.getItem('bazaarbuddy_account') && <p className="demo-note">First time here? You can log in with any email/phone and password, or create an account.</p>}
      </div>
      <style>{`
        .login-page{min-height:100vh;background:#081225;color:#edf3ff;display:flex;align-items:center;justify-content:center;padding:24px;position:relative;overflow:hidden;font-family:Inter,system-ui,sans-serif}.login-glow{position:absolute;border-radius:50%;filter:blur(100px);opacity:.28}.login-glow-one{width:360px;height:360px;background:#356bd5;top:-130px;left:15%}.login-glow-two{width:380px;height:380px;background:#743bbd;bottom:-160px;right:12%}.login-card{position:relative;width:100%;max-width:430px;background:rgba(15,29,57,.94);border:1px solid #2a3d68;border-radius:20px;padding:32px;box-shadow:0 25px 70px rgba(0,0,0,.4)}.login-brand{display:flex;align-items:center;justify-content:center;gap:10px;font-size:19px;font-weight:800;margin-bottom:26px}.login-logo{width:42px;height:42px;border-radius:12px;background:linear-gradient(135deg,#4b80e2,#345bb8);display:flex;align-items:center;justify-content:center}.login-tabs{display:grid;grid-template-columns:1fr 1fr;background:#091426;border:1px solid #22365e;padding:4px;border-radius:10px;margin-bottom:25px}.login-tabs button{border:0;background:transparent;color:#8da0c5;padding:10px;border-radius:7px;cursor:pointer;font-weight:600}.login-tabs button.selected{background:#315ebc;color:#fff}.login-card h1{font-size:25px;margin:0 0 7px}.login-sub{color:#8fa1c4;font-size:14px;margin:0 0 23px}.login-card form{display:flex;flex-direction:column;gap:15px}.login-card label{font-size:12px;color:#b9c6df}.login-card input{display:block;width:100%;box-sizing:border-box;margin-top:7px;background:#091426;border:1px solid #293d67;border-radius:9px;color:#fff;padding:12px 13px;outline:none}.login-card input:focus{border-color:#5d8fea}.login-submit{margin-top:4px;border:0;border-radius:9px;padding:13px;background:linear-gradient(90deg,#3f78d8,#6550c8);color:#fff;font-weight:700;cursor:pointer}.login-error{background:rgba(220,70,70,.12);border:1px solid rgba(220,100,100,.35);color:#ffb1b1;padding:10px;border-radius:8px;font-size:12px}.login-switch{text-align:center;color:#8fa1c4;font-size:13px;margin:20px 0 0}.login-switch button{border:0;background:none;color:#75a3ff;cursor:pointer;font-weight:700}.demo-note{text-align:center;color:#687b9f;font-size:11px;line-height:1.5;margin:14px 0 0}
      `}</style>
    </div>
  );
}

export { AUTH_KEY };
