import React from "react";
import { NavLink } from "react-router-dom";
import {
  LayoutDashboard,
  ShoppingCart,
  Package,
  BookText,
  Truck,
  Wallet,
  BarChart3,
  Users,
  Bell,
  Settings as SettingsIcon,
} from "lucide-react";

const navItems = [
  { path: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { path: "/billing", label: "Billing / POS", icon: ShoppingCart },
  { path: "/inventory", label: "Inventory", icon: Package },
  { path: "/udhar", label: "Udhar", icon: BookText },
  { path: "/suppliers", label: "Suppliers", icon: Truck },
  { path: "/expenses", label: "Expenses", icon: Wallet },
  { path: "/reports", label: "Analytics & Reports", icon: BarChart3 },
  { path: "/customers", label: "Customers", icon: Users },
  { path: "/notifications", label: "Notifications", icon: Bell },
  { path: "/settings", label: "Settings", icon: SettingsIcon },
];

export default function Sidebar() {
  return (
    <>
      <aside className="bb-sidebar">

        <div className="bb-sidebar-logo">
          <div className="bb-logo-icon">
            🛍️
          </div>

          <span>BazaarBuddy AI</span>
        </div>

        <nav className="bb-sidebar-nav">

          {navItems.map(({ path, label, icon: Icon }) => (
            <NavLink
              key={path}
              to={path}
              className={({ isActive }) =>
                `bb-nav-link ${isActive ? "active" : ""}`
              }
            >
              <Icon size={18} />
              <span>{label}</span>
            </NavLink>
          ))}

        </nav>

        <button className="bb-logout" onClick={() => { localStorage.removeItem("bazaarbuddy_auth"); window.location.href = "/login"; }}>Log out</button>

        <div className="bb-sidebar-footer">
          Every kirana, one ledger.
          <br />
          Built for Indian dukaandars.
        </div>

      </aside>

      <style>{`

        .bb-sidebar {
          width: 250px;
          min-width: 250px;
          height: 100vh;

          position: sticky;
          top: 0;

          background: #0D1A38;
          border-right: 1px solid #22335C;

          display: flex;
          flex-direction: column;

          padding: 24px 16px;

          color: #EAF0FB;

          overflow-y: auto;
        }

        .bb-sidebar-logo {
          display: flex;
          align-items: center;

          gap: 10px;

          padding: 0 10px;

          margin-bottom: 28px;

          font-size: 17px;
          font-weight: 700;

          white-space: nowrap;
        }

        .bb-logo-icon {
          width: 40px;
          height: 40px;

          border-radius: 11px;

          display: flex;
          align-items: center;
          justify-content: center;

          background: linear-gradient(
            135deg,
            #4A7FE0,
            #2F5FC0
          );

          font-size: 20px;
        }

        .bb-sidebar-nav {
          display: flex;
          flex-direction: column;

          gap: 5px;

          flex: 1;
        }

        .bb-nav-link {
          display: flex;
          align-items: center;

          gap: 12px;

          width: 100%;

          padding: 11px 13px;

          border-radius: 10px;

          color: #8CA0D0;

          text-decoration: none;

          font-size: 14px;

          transition: all 0.2s ease;
        }

        .bb-nav-link:hover {
          background: rgba(74, 127, 224, 0.10);
          color: #EAF0FB;
        }

        .bb-nav-link.active {
          background: rgba(74, 127, 224, 0.18);

          color: #FFFFFF;

          font-weight: 600;

          border-left: 3px solid #4A7FE0;
        }

        .bb-logout{border:1px solid #2a3d68;background:#101f3d;color:#9db0d3;border-radius:9px;padding:10px 12px;cursor:pointer;font-size:13px;text-align:left;margin-top:10px}.bb-logout:hover{background:#172b50;color:#fff}.bb-sidebar-footer {
          border-top: 1px solid #22335C;

          padding: 16px 8px 0;

          margin-top: 16px;

          color: #7184B1;

          font-size: 12px;

          line-height: 1.5;
        }

        @media (max-width: 800px) {

          .bb-sidebar {
            width: 210px;
            min-width: 210px;
          }

        }

      `}</style>
    </>
  );
}