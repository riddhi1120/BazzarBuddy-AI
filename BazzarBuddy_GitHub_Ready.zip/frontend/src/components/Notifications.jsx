import React, { useState } from "react";
import Layout from "./Layout";

const initialNotifications = [
  { id: 1, type: "Udhar Due", message: "Amit Patel's udhar of ₹1,200 is overdue by 5 days", time: "2 hours ago", read: false },
  { id: 2, type: "Low Stock", message: "Sunflower Oil (1L) stock is below reorder level", time: "5 hours ago", read: false },
  { id: 3, type: "Payments", message: "Received ₹2,300 via UPI from Billing", time: "Today, 10:15 AM", read: true },
  { id: 4, type: "Udhar Due", message: "Vikram Singh's udhar of ₹2,400 is overdue by 3 days", time: "Yesterday", read: true },
  { id: 5, type: "Low Stock", message: "Basmati Rice (5kg) stock is below reorder level", time: "2 days ago", read: true },
];

const filters = ["All", "Low Stock", "Udhar Due", "Payments"];

const typeIcon = {
  "Udhar Due": "💰",
  "Low Stock": "📦",
  Payments: "✅",
};

export default function Notifications() {
  const [notifications, setNotifications] = useState(initialNotifications);
  const [filter, setFilter] = useState("All");

  const filtered =
    filter === "All" ? notifications : notifications.filter((n) => n.type === filter);

  const markRead = (id) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  };

  return (
    <Layout>
    <div className="text-white p-8">
      <div className="mb-8">
        <h1 className="text-2xl font-semibold">Notifications</h1>
        <p className="text-sm text-gray-400 mt-1">Low stock alerts, udhar reminders and payment updates</p>
      </div>

      <div className="bg-[#15151f] border border-[#2a2a3a] rounded-xl p-6">
        <div className="flex gap-2 mb-5">
          {filters.map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-2 rounded-lg text-sm ${
                filter === f
                  ? "bg-gradient-to-r from-fuchsia-500 to-blue-500 text-white font-medium"
                  : "bg-[#0b0b12] border border-[#2a2a3a] text-gray-400 hover:text-white"
              }`}
            >
              {f}
            </button>
          ))}
        </div>

        <div className="space-y-2">
          {filtered.map((n) => (
            <div
              key={n.id}
              className={`flex items-start justify-between p-4 rounded-lg border ${
                n.read ? "border-[#20202c] bg-transparent" : "border-fuchsia-500/30 bg-fuchsia-500/5"
              }`}
            >
              <div className="flex gap-3">
                <span className="text-lg">{typeIcon[n.type]}</span>
                <div>
                  <p className="text-sm">{n.message}</p>
                  <p className="text-xs text-gray-500 mt-1">{n.time}</p>
                </div>
              </div>
              {!n.read && (
                <button
                  onClick={() => markRead(n.id)}
                  className="text-blue-400 hover:text-blue-300 text-xs font-medium whitespace-nowrap"
                >
                  Mark as read
                </button>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
    </Layout>
  );
}
