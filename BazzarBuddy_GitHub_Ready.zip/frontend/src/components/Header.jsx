import { useAuth } from "../context/AuthContext";

function getInitials(fullName) {
  if (!fullName) return "";
  return fullName.trim().split(/\s+/).map(w => w[0].toUpperCase()).slice(0, 2).join("");
}

function Header() {
  const { user } = useAuth();
  return (
    <div className="navbar">
      <div className="avatar-circle">{getInitials(user?.name)}</div>
    </div>
  );
}