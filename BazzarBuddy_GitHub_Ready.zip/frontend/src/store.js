const KEYS = {
  products: 'bazaarbuddy_products_v2',
  customers: 'bazaarbuddy_customers_v2',
  bills: 'bazaarbuddy_bills_v2',
  udhar: 'bazaarbuddy_udhar_v2',
  manualPayments: 'bazaarbuddy_manual_payments_v1',
};

export const seedProducts = [
  { id: 1, name: 'Milk', brand: 'Amul', category: 'Dairy', qty: 500, unit: 'ml', price: 32, costPrice: 28, stock: 40, lowStock: 10, expiry: '', image: '' },
  { id: 2, name: 'Salt', brand: 'Tata', category: 'Groceries', qty: 1, unit: 'kg', price: 24, costPrice: 20, stock: 60, lowStock: 10, expiry: '', image: '' },
  { id: 3, name: 'Biscuit', brand: 'Parle-G', category: 'Snacks', qty: 250, unit: 'g', price: 20, costPrice: 16, stock: 120, lowStock: 20, expiry: '2027-03-01', image: '' },
  { id: 4, name: 'Atta', brand: 'Aashirvaad', category: 'Groceries', qty: 5, unit: 'kg', price: 265, costPrice: 240, stock: 18, lowStock: 5, expiry: '', image: '' },
  { id: 5, name: 'Sunflower Oil', brand: 'Fortune', category: 'Oil', qty: 1, unit: 'L', price: 145, costPrice: 130, stock: 22, lowStock: 6, expiry: '2027-01-15', image: '' },
  { id: 6, name: 'Noodles', brand: 'Maggi', category: 'Snacks', qty: 70, unit: 'g', price: 14, costPrice: 11, stock: 80, lowStock: 15, expiry: '2027-05-01', image: '' },
  { id: 7, name: 'Toothpaste', brand: 'Colgate', category: 'Personal Care', qty: 100, unit: 'g', price: 55, costPrice: 46, stock: 35, lowStock: 8, expiry: '2028-02-01', image: '' },
  { id: 8, name: 'Tea', brand: 'Red Label', category: 'Beverages', qty: 250, unit: 'g', price: 130, costPrice: 112, stock: 26, lowStock: 7, expiry: '2027-08-01', image: '' },
  { id: 9, name: 'Detergent', brand: 'Surf Excel', category: 'Home Care', qty: 1, unit: 'kg', price: 135, costPrice: 118, stock: 15, lowStock: 5, expiry: '', image: '' },
  { id: 10, name: 'Basmati Rice', brand: 'India Gate', category: 'Groceries', qty: 5, unit: 'kg', price: 420, costPrice: 380, stock: 12, lowStock: 4, expiry: '', image: '' },
];

export const seedCustomers = [
  { id: 1, name: 'Ramesh Kumar', phone: '9876543210', totalPurchases: 12400, udharBalance: 850 },
  { id: 2, name: 'Amit Patel', phone: '9988776655', totalPurchases: 5600, udharBalance: 1200 },
  { id: 3, name: 'Vikram Singh', phone: '9776655443', totalPurchases: 9800, udharBalance: 2400 },
  { id: 4, name: 'Priya Sharma', phone: '9123456789', totalPurchases: 8200, udharBalance: 0 },
  { id: 5, name: 'Sunita Devi', phone: '9001122334', totalPurchases: 3150, udharBalance: 0 },
];

export const seedBills = [];
export const seedUdhar = [
  { id: 1, customerId: 1, customer: 'Ramesh Kumar', phone: '9876543210', billTotal: 1000, paid: 150, pending: 850, date: '2026-08-02', status: 'pending' },
  { id: 2, customerId: 2, customer: 'Amit Patel', phone: '9988776655', billTotal: 1200, paid: 0, pending: 1200, date: '2026-07-28', status: 'pending' },
  { id: 3, customerId: 3, customer: 'Vikram Singh', phone: '9776655443', billTotal: 2400, paid: 0, pending: 2400, date: '2026-07-20', status: 'pending' },
];

export function read(key, fallback) {
  try {
    const value = localStorage.getItem(key);
    return value ? JSON.parse(value) : fallback;
  } catch {
    return fallback;
  }
}

export function write(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
  window.dispatchEvent(new CustomEvent('bazaarbuddy-data', { detail: key }));
}

export function getProducts() { return read(KEYS.products, seedProducts); }
export function saveProducts(v) { write(KEYS.products, v); }
export function getCustomers() { return read(KEYS.customers, seedCustomers); }
export function saveCustomers(v) { write(KEYS.customers, v); }
export function getBills() { return read(KEYS.bills, seedBills); }
export function saveBills(v) { write(KEYS.bills, v); }
export function getUdhar() { return read(KEYS.udhar, seedUdhar); }
export function saveUdhar(v) { write(KEYS.udhar, v); }
export function getManualPayments() { return read(KEYS.manualPayments, []); }
export function saveManualPayments(v) { write(KEYS.manualPayments, v); }

export function money(n) {
  return `₹${Number(n || 0).toLocaleString('en-IN')}`;
}

export function formatQty(product) {
  return `${product.qty ?? ''} ${product.unit || 'pcs'}`.trim();
}

export function unitOptions() {
  return ['kg', 'g', 'L', 'ml', 'pcs', 'packet', 'box'];
}
