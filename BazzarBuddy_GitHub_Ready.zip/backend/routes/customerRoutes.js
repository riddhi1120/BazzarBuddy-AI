const express = require('express');
const router = express.Router();
const Customer = require('../models/Customer');

router.get('/', async (req,res)=>{ try { res.json(await Customer.find().sort({name:1})); } catch(e){ res.status(500).json({error:e.message}); } });
router.post('/', async (req,res)=>{ try { res.status(201).json(await Customer.create(req.body)); } catch(e){ res.status(400).json({error:e.message}); } });
router.patch('/:id/payment', async (req,res)=>{ try { const amount=Math.max(0,Number(req.body.amount||0)); const c=await Customer.findById(req.params.id); if(!c)return res.status(404).json({error:'Customer not found'}); c.udharBalance=Math.max(0,c.udharBalance-amount); await c.save(); res.json(c); } catch(e){res.status(400).json({error:e.message});} });
module.exports=router;
