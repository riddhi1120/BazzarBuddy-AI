const express = require('express');
const router = express.Router();
const {
  getProducts,
  getLowStockProducts,
  getProductByBarcode,
  createProduct,
  updateProduct,
  deleteProduct,
  adjustStock
} = require('../controllers/productController');

router.get('/', getProducts);
router.get('/low-stock', getLowStockProducts);
router.get('/barcode/:code', getProductByBarcode);
router.post('/', createProduct);
router.put('/:id', updateProduct);
router.delete('/:id', deleteProduct);
router.patch('/:id/stock', adjustStock);

module.exports = router;
