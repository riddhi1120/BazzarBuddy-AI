const mongoose = require('mongoose');

const customerSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    phone: { type: String, required: true, unique: true, trim: true },
    loyaltyPoints: { type: Number, default: 0 },
    totalPurchases: { type: Number, default: 0 },
    udharBalance: { type: Number, default: 0, min: 0 },
    purchaseHistory: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Order' }]
  },
  { timestamps: true }
);

module.exports = mongoose.model('Customer', customerSchema);
