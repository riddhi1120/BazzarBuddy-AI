const mongoose = require('mongoose');

const productSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    brand: { type: String, trim: true, default: '' },
    category: { type: String, required: true },
    qty: { type: Number, default: 1, min: 0 },
    unit: { type: String, enum: ['kg', 'g', 'L', 'ml', 'pcs', 'packet', 'box'], default: 'pcs' },
    price: { type: Number, required: true, min: 0 },
    costPrice: { type: Number, required: true, min: 0 },
    stock: { type: Number, required: true, default: 0, min: 0 },
    lowStockThreshold: { type: Number, default: 10, min: 0 },
    expiry: { type: Date },
    image: { type: String, default: '' },
    barcode: { type: String, unique: true, sparse: true },
    aiTags: [{ type: String }]
  },
  { timestamps: true }
);

productSchema.virtual('isLowStock').get(function () {
  return this.stock <= this.lowStockThreshold;
});
productSchema.virtual('profit').get(function () { return this.price - this.costPrice; });
productSchema.set('toJSON', { virtuals: true });

module.exports = mongoose.model('Product', productSchema);
