require('dotenv').config();
const express = require('express');
const cors = require('cors');
const http = require('http');
const { Server } = require('socket.io');

const connectDB = require('./config/db');
const startUdpServer = require('./udp/udpServer');

const productRoutes = require('./routes/productRoutes');
const orderRoutes = require('./routes/orderRoutes');
const customerRoutes = require('./routes/customerRoutes');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.use('/api/products', productRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/customers', customerRoutes);

app.get('/', (req, res) => {
  res.json({ message: 'BazaarBuddy-AI backend is running' });
});

// Socket.io connection (frontend clients)
io.on('connection', (socket) => {
  console.log('🔌 Frontend connected:', socket.id);

  socket.on('disconnect', () => {
    console.log('❌ Frontend disconnected:', socket.id);
  });
});

// Start everything
const PORT = process.env.PORT || 3000;
const UDP_PORT = process.env.UDP_PORT || 41234;

connectDB().then(() => {
  server.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
  });
  startUdpServer(io, UDP_PORT);
});
