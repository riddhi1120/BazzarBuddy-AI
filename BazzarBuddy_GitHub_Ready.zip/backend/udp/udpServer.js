const dgram = require('dgram');

/**
 * Starts a UDP server that listens for messages from local devices
 * (weighing scale, network barcode scanner, etc.) and broadcasts
 * incoming data to all connected frontend clients via Socket.io.
 *
 * Expected UDP message format (simple example): "WEIGHT:1.250"
 */
function startUdpServer(io, port) {
  const udpSocket = dgram.createSocket('udp4');

  udpSocket.on('message', (msg, rinfo) => {
    const text = msg.toString().trim();
    console.log(`📡 UDP data from ${rinfo.address}:${rinfo.port} -> ${text}`);

    if (text.startsWith('WEIGHT:')) {
      const weight = parseFloat(text.split(':')[1]);
      io.emit('scale-weight', { weight, source: rinfo.address });
    } else {
      io.emit('udp-raw', { message: text, source: rinfo.address });
    }
  });

  udpSocket.on('error', (err) => {
    console.error('UDP server error:', err);
    udpSocket.close();
  });

  udpSocket.on('listening', () => {
    const address = udpSocket.address();
    console.log(`✅ UDP server listening on ${address.address}:${address.port}`);
  });

  udpSocket.bind(port);
  return udpSocket;
}

module.exports = startUdpServer;
