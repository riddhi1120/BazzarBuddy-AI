const Order = require('../models/Order');
const Product = require('../models/Product');
const Customer = require('../models/Customer');

exports.getOrders = async (req, res) => {
  try {
    const orders = await Order.find().populate('items.product').populate('customer').sort({ createdAt: -1 });
    res.json(orders);
  } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.createOrder = async (req, res) => {
  try {
    const { items, customerPhone, customerName, paymentMode, paidAmount = 0, tax = 0 } = req.body;
    if (!items?.length) return res.status(400).json({ error: 'Order must have at least one item' });

    let subtotal = 0;
    const orderItems = [];
    const productsToSave = [];

    for (const line of items) {
      const product = await Product.findById(line.product);
      if (!product) return res.status(404).json({ error: `Product ${line.product} not found` });
      const qty = Number(line.qty);
      if (!qty || qty < 1) return res.status(400).json({ error: 'Invalid quantity' });
      if (product.stock < qty) return res.status(400).json({ error: `Insufficient stock for ${product.name}` });
      orderItems.push({ product: product._id, qty, price: product.price, costPrice: product.costPrice });
      subtotal += product.price * qty;
      product.stock -= qty;
      productsToSave.push(product);
    }

    const totalAmount = subtotal + Number(tax || 0);
    const paid = Math.min(Math.max(Number(paidAmount || 0), 0), totalAmount);
    const pendingAmount = totalAmount - paid;
    if (pendingAmount > 0 && !customerPhone) return res.status(400).json({ error: 'Customer mobile is required for pending udhar' });

    for (const product of productsToSave) await product.save();

    let customer = null;
    if (customerPhone) {
      customer = await Customer.findOne({ phone: customerPhone });
      if (!customer) customer = await Customer.create({ name: customerName || 'Customer', phone: customerPhone });
      customer.loyaltyPoints += Math.floor(totalAmount / 100);
      customer.totalPurchases += totalAmount;
      customer.udharBalance += pendingAmount;
    }

    const order = await Order.create({
      billNumber: `BB-${Date.now()}`,
      customer: customer?._id,
      items: orderItems,
      subtotal,
      tax: Number(tax || 0),
      totalAmount,
      paidAmount: paid,
      pendingAmount,
      paymentMode: paymentMode || 'Cash'
    });

    if (customer) { customer.purchaseHistory.push(order._id); await customer.save(); }
    res.status(201).json(await order.populate(['items.product', 'customer']));
  } catch (err) { res.status(400).json({ error: err.message }); }
};
