BAZAARBUDDY AI / KIRANAAA - UPDATED BUILD

FRONTEND
1. Open CMD.
2. cd C:\Users\Riddhi\Kiranaaa\frontend
3. npm install
4. npm run dev

BACKEND (only when you want MongoDB/API server running)
1. Open another CMD.
2. cd C:\Users\Riddhi\Kiranaaa\backend
3. npm install
4. npm start

MAIN UPDATES
- Dashboard now combines today's sales + analytics.
- Inventory supports product photo, brand, pack quantity, kg/g/L/ml/pcs/packet/box, buying price, selling price, profit, stock and expiry.
- Billing reads the inventory products and supports customer selection.
- Billing supports full or partial payment; remaining amount becomes customer udhar.
- Customers store name + mobile + purchase total + pending udhar.
- Udhar is grouped by customer and supports partial payment collection.
- Inventory stock decreases automatically after a bill.
- Customer udhar and purchase total update automatically after billing.
- Data is shared between modules through localStorage so the frontend works even before MongoDB is connected.

IMPORTANT
The zip intentionally excludes node_modules. Run npm install on your Windows PC so Vite gets the correct Windows/native dependencies.
